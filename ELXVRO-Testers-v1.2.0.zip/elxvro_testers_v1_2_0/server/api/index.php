<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

function respond($data = null, int $status = 200): never {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $message, int $status = 400): never {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function oauthPage(string $title, string $message, bool $success): never {
    header('Content-Type: text/html; charset=utf-8');
    http_response_code($success ? 200 : 400);
    $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    $accent = $success ? '#4ade80' : '#fb7185';
    echo <<<HTML
<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{$title}</title>
<style>body{margin:0;background:#090d15;color:#fff;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;display:grid;place-items:center;min-height:100vh;padding:24px;box-sizing:border-box}.card{max-width:520px;width:100%;background:#121826;border:1px solid #2a344a;border-radius:24px;padding:28px;box-sizing:border-box}.mark{width:56px;height:56px;border-radius:18px;background:{$accent}22;color:{$accent};display:grid;place-items:center;font-size:28px;font-weight:800;margin-bottom:20px}h1{font-size:28px;margin:0 0 10px}p{color:#94a3b8;line-height:1.55;margin:0}.brand{margin-top:24px;color:#64748b;font-size:13px}</style></head><body><div class="card"><div class="mark">✓</div><h1>{$title}</h1><p>{$message}</p><div class="brand">ELXVRO Testers</div></div></body></html>
HTML;
    exit;
}

function body(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function db(): PDO {
    global $config;
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host=' . $config['DB_HOST'] . ';dbname=' . $config['DB_NAME'] . ';charset=utf8mb4',
            $config['DB_USER'],
            $config['DB_PASS'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
    } catch (Throwable $e) {
        fail('Veritabanı bağlantısı kurulamadı. config.php ayarlarını kontrol edin.', 500);
    }
    return $pdo;
}

function bearerToken(): ?string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$header && function_exists('getallheaders')) {
        $h = getallheaders();
        $header = $h['Authorization'] ?? $h['authorization'] ?? '';
    }
    return preg_match('/Bearer\s+(.+)/i', $header, $m) ? trim($m[1]) : null;
}

function bindMemberships(int $userId, string $email): void {
    $stmt = db()->prepare('UPDATE project_members SET user_id=?, name=COALESCE(NULLIF(name,\'\'),(SELECT name FROM users WHERE id=?)) WHERE user_id IS NULL AND LOWER(email)=LOWER(?)');
    $stmt->execute([$userId, $userId, $email]);
}

function currentUser(array $roles = []): array {
    $token = bearerToken();
    if (!$token) fail('Oturum gerekli.', 401);
    $hash = hash('sha256', $token);
    $stmt = db()->prepare('SELECT u.id,u.name,u.email,u.role,u.avatar_url FROM api_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>NOW() LIMIT 1');
    $stmt->execute([$hash]);
    $user = $stmt->fetch();
    if (!$user) fail('Oturum süresi dolmuş veya geçersiz.', 401);
    if ($roles && !in_array($user['role'], $roles, true)) fail('Bu işlem için yetkiniz yok.', 403);
    bindMemberships((int)$user['id'], (string)$user['email']);
    $user['id'] = (int)$user['id'];
    return $user;
}

function createToken(int $userId): string {
    global $config;
    $token = bin2hex(random_bytes(32));
    $days = max(1, (int)($config['TOKEN_DAYS'] ?? 90));
    $stmt = db()->prepare('INSERT INTO api_tokens(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL ? DAY))');
    $stmt->execute([$userId, hash('sha256', $token), $days]);
    return $token;
}

function cleanEmail(string $email): string {
    $email = strtolower(trim($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Geçerli bir e-posta adresi girin.');
    return $email;
}

function requireOwner(int $projectId, int $adminId): array {
    $stmt = db()->prepare('SELECT * FROM projects WHERE id=? AND created_by=? LIMIT 1');
    $stmt->execute([$projectId, $adminId]);
    $project = $stmt->fetch();
    if (!$project) fail('Proje bulunamadı.', 404);
    return $project;
}

function getOpenProject(int $projectId): array {
    $stmt = db()->prepare('SELECT * FROM projects WHERE id=? AND is_open=1 LIMIT 1');
    $stmt->execute([$projectId]);
    $project = $stmt->fetch();
    if (!$project) fail('Bu test şu anda katılıma açık değil.', 404);
    return $project;
}

function projectStats(int $projectId, array $project): array {
    $stmt = db()->prepare("SELECT COUNT(*) total, COUNT(user_id) registered, SUM(status<>'invited') joined, SUM(status IN ('installed','testing','completed')) installed FROM project_members WHERE project_id=?");
    $stmt->execute([$projectId]);
    $s = $stmt->fetch() ?: ['total'=>0,'registered'=>0,'joined'=>0,'installed'=>0];
    $elapsed = 0;
    if (!empty($project['test_start_date'])) {
        $start = new DateTimeImmutable((string)$project['test_start_date']);
        $today = new DateTimeImmutable('today');
        if ($start <= $today) $elapsed = ((int)$start->diff($today)->days) + 1;
    }
    $duration = max(1, (int)($project['test_duration_days'] ?? 14));
    $minimum = max(1, (int)($project['min_testers'] ?? 12));
    $registered = (int)($s['registered'] ?? 0);
    return [
        'total' => (int)($s['total'] ?? 0),
        'registered' => $registered,
        'joined' => (int)($s['joined'] ?? 0),
        'installed' => (int)($s['installed'] ?? 0),
        'minimum_testers' => $minimum,
        'missing_testers' => max(0, $minimum - $registered),
        'download_unlocked' => $registered >= $minimum,
        'elapsed_days' => min($elapsed, $duration),
        'remaining_days' => max(0, $duration - $elapsed),
        'completed' => $elapsed >= $duration,
    ];
}

function requireDownloadUnlocked(int $projectId, array $project): array {
    $stats = projectStats($projectId, $project);
    if (($stats['download_unlocked'] ?? false) !== true) {
        $missing = (int)($stats['missing_testers'] ?? 0);
        fail('Google Play test bağlantısı henüz kilitli. ' . $missing . ' testçi daha gerekli.', 423);
    }
    return $stats;
}

function isAdminEmail(string $email): bool {
    global $config;
    $email = strtolower(trim($email));
    $list = $config['ADMIN_EMAILS'] ?? [];
    if (!is_array($list)) return false;
    foreach ($list as $item) {
        if (strtolower(trim((string)$item)) === $email) return true;
    }
    return false;
}

function googleConfigured(): bool {
    global $config;
    foreach (['GOOGLE_CLIENT_ID','GOOGLE_CLIENT_SECRET','GOOGLE_REDIRECT_URI'] as $key) {
        $v = trim((string)($config[$key] ?? ''));
        if ($v === '' || str_contains($v, 'YOUR_')) return false;
    }
    return true;
}

function httpJson(string $url, string $method = 'GET', array $headers = [], ?array $form = null): array {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($form ?? []));
        }
        $raw = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($raw === false) throw new RuntimeException('Google bağlantısı kurulamadı: ' . $error);
        $data = json_decode((string)$raw, true);
        if ($status < 200 || $status >= 300 || !is_array($data)) throw new RuntimeException('Google sunucusu geçersiz yanıt verdi.');
        return $data;
    }

    $options = ['http' => ['method' => $method, 'timeout' => 20, 'ignore_errors' => true, 'header' => implode("\r\n", $headers)]];
    if ($method === 'POST') {
        $options['http']['header'] .= "\r\nContent-Type: application/x-www-form-urlencoded";
        $options['http']['content'] = http_build_query($form ?? []);
    }
    $raw = @file_get_contents($url, false, stream_context_create($options));
    if ($raw === false) throw new RuntimeException('Google bağlantısı kurulamadı. Hosting üzerinde cURL etkinleştirmeniz önerilir.');
    $data = json_decode($raw, true);
    if (!is_array($data)) throw new RuntimeException('Google sunucusu geçersiz yanıt verdi.');
    return $data;
}

function upsertGoogleUser(array $profile): int {
    $sub = trim((string)($profile['sub'] ?? ''));
    $email = strtolower(trim((string)($profile['email'] ?? '')));
    $name = trim((string)($profile['name'] ?? ''));
    $picture = trim((string)($profile['picture'] ?? ''));
    $verified = $profile['email_verified'] ?? $profile['verified_email'] ?? true;

    if ($sub === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Google hesap bilgileri eksik.');
    if ($verified === false || $verified === 'false' || $verified === 0 || $verified === '0') throw new RuntimeException('Google e-posta adresi doğrulanmamış.');
    if ($name === '') $name = explode('@', $email)[0];

    $pdo = db();
    $stmt = $pdo->prepare('SELECT id,role FROM users WHERE google_sub=? OR email=? LIMIT 1');
    $stmt->execute([$sub, $email]);
    $user = $stmt->fetch();
    $admin = isAdminEmail($email);

    if ($user) {
        $role = $admin ? 'admin' : (string)$user['role'];
        $stmt = $pdo->prepare('UPDATE users SET name=?,email=?,google_sub=?,avatar_url=?,role=?,last_login_at=NOW() WHERE id=?');
        $stmt->execute([$name,$email,$sub,$picture !== '' ? $picture : null,$role,(int)$user['id']]);
        $id = (int)$user['id'];
    } else {
        $role = $admin ? 'admin' : 'tester';
        $stmt = $pdo->prepare('INSERT INTO users(name,email,password_hash,google_sub,avatar_url,role,last_login_at) VALUES(?,?,NULL,?,?,?,NOW())');
        $stmt->execute([$name,$email,$sub,$picture !== '' ? $picture : null,$role]);
        $id = (int)$pdo->lastInsertId();
    }

    bindMemberships($id, $email);
    return $id;
}

function enrollUserInProject(array $user, int $projectId): int {
    getOpenProject($projectId);
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO project_members(project_id,user_id,email,name,status) VALUES(?,?,?,?, 'invited') ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), name=VALUES(name)");
    $stmt->execute([$projectId,(int)$user['id'],(string)$user['email'],(string)$user['name']]);
    $stmt = $pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND LOWER(email)=LOWER(?) LIMIT 1');
    $stmt->execute([$projectId,(string)$user['email']]);
    $memberId = (int)$stmt->fetchColumn();

    $stmt = $pdo->prepare('SELECT id FROM tester_groups WHERE project_id=? ORDER BY id ASC LIMIT 1');
    $stmt->execute([$projectId]);
    $groupId = (int)($stmt->fetchColumn() ?: 0);
    if ($groupId > 0) {
        $stmt = $pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)');
        $stmt->execute([$groupId,$memberId]);
    }
    return $memberId;
}

function markGoogleSessionFailed(string $state, string $message): void {
    if ($state === '') return;
    $stmt = db()->prepare("UPDATE google_login_sessions SET status='failed',error_message=?,completed_at=NOW() WHERE state_hash=?");
    $stmt->execute([mb_substr($message, 0, 255), hash('sha256', $state)]);
}

function handleGoogleCallback(): never {
    global $config;
    $state = trim((string)($_GET['state'] ?? ''));
    $code = trim((string)($_GET['code'] ?? ''));
    $oauthError = trim((string)($_GET['error'] ?? ''));

    try {
        if (!googleConfigured()) throw new RuntimeException('Google OAuth sunucu ayarları tamamlanmamış.');
        if ($state === '') throw new RuntimeException('Giriş durumu eksik.');

        $stmt = db()->prepare("SELECT id,status FROM google_login_sessions WHERE state_hash=? AND expires_at>NOW() LIMIT 1");
        $stmt->execute([hash('sha256', $state)]);
        $session = $stmt->fetch();
        if (!$session) throw new RuntimeException('Google giriş oturumu bulunamadı veya süresi doldu.');
        if ($session['status'] === 'complete') oauthPage('Giriş başarılı', 'Google hesabınız daha önce doğrulandı. ELXVRO Testers uygulamasına geri dönebilirsiniz.', true);
        if ($session['status'] === 'failed') throw new RuntimeException('Bu giriş denemesi daha önce tamamlanamadı. Uygulamadan tekrar deneyin.');
        if ($oauthError !== '') throw new RuntimeException('Google girişi iptal edildi: ' . $oauthError);
        if ($code === '') throw new RuntimeException('Google yetkilendirme kodu alınamadı.');

        $token = httpJson('https://oauth2.googleapis.com/token', 'POST', ['Accept: application/json'], [
            'client_id' => (string)$config['GOOGLE_CLIENT_ID'],
            'client_secret' => (string)$config['GOOGLE_CLIENT_SECRET'],
            'code' => $code,
            'grant_type' => 'authorization_code',
            'redirect_uri' => (string)$config['GOOGLE_REDIRECT_URI'],
        ]);
        $accessToken = trim((string)($token['access_token'] ?? ''));
        if ($accessToken === '') throw new RuntimeException('Google erişim anahtarı alınamadı.');

        $profile = httpJson('https://openidconnect.googleapis.com/v1/userinfo', 'GET', ['Authorization: Bearer ' . $accessToken, 'Accept: application/json']);
        $userId = upsertGoogleUser($profile);

        $stmt = db()->prepare("UPDATE google_login_sessions SET status='complete',user_id=?,error_message=NULL,completed_at=NOW() WHERE id=?");
        $stmt->execute([$userId, (int)$session['id']]);
        oauthPage('Giriş başarılı', 'Google hesabınız doğrulandı. ELXVRO Testers uygulamasına geri dönebilirsiniz.', true);
    } catch (Throwable $e) {
        markGoogleSessionFailed($state, $e->getMessage());
        oauthPage('Giriş tamamlanamadı', $e->getMessage(), false);
    }
}

$action = $_GET['action'] ?? 'health';
$method = $_SERVER['REQUEST_METHOD'];
$input = body();

if ($action === 'google_callback') handleGoogleCallback();

try {
    if ($action === 'health') {
        respond(['service'=>'ELXVRO Testers API','version'=>'1.2.0','php'=>PHP_VERSION,'time'=>date(DATE_ATOM),'google_configured'=>googleConfigured()]);
    }

    if ($action === 'google_begin' && $method === 'POST') {
        if (!googleConfigured()) fail('Google OAuth ayarları tamamlanmamış. server/config.php dosyasını düzenleyin.', 503);
        $pdo = db();
        $pdo->exec("DELETE FROM google_login_sessions WHERE expires_at<NOW() OR (status<>'pending' AND completed_at<DATE_SUB(NOW(), INTERVAL 1 DAY))");

        $sessionId = bin2hex(random_bytes(32));
        $state = bin2hex(random_bytes(32));
        $stmt = $pdo->prepare("INSERT INTO google_login_sessions(session_hash,state_hash,status,expires_at) VALUES(?,?,'pending',DATE_ADD(NOW(),INTERVAL 10 MINUTE))");
        $stmt->execute([hash('sha256',$sessionId), hash('sha256',$state)]);

        $params = [
            'client_id' => (string)$config['GOOGLE_CLIENT_ID'],
            'redirect_uri' => (string)$config['GOOGLE_REDIRECT_URI'],
            'response_type' => 'code',
            'scope' => 'openid email profile',
            'state' => $state,
            'prompt' => 'select_account',
            'include_granted_scopes' => 'true',
        ];
        respond(['session_id'=>$sessionId,'auth_url'=>'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params)]);
    }

    if ($action === 'google_poll' && $method === 'POST') {
        $sessionId = trim((string)($input['session_id'] ?? ''));
        if ($sessionId === '') fail('Giriş oturumu eksik.');
        $pdo = db();
        $stmt = $pdo->prepare('SELECT id,status,user_id,error_message,IF(expires_at<=NOW(),1,0) expired FROM google_login_sessions WHERE session_hash=? LIMIT 1');
        $stmt->execute([hash('sha256',$sessionId)]);
        $session = $stmt->fetch();
        if (!$session) fail('Google giriş oturumu bulunamadı.', 404);
        if ((int)$session['expired'] === 1) {
            $pdo->prepare("UPDATE google_login_sessions SET status='failed',error_message='Giriş süresi doldu.' WHERE id=?")->execute([(int)$session['id']]);
            respond(['status'=>'failed','message'=>'Google giriş süresi doldu.']);
        }
        if ($session['status'] === 'failed') respond(['status'=>'failed','message'=>$session['error_message'] ?: 'Google ile giriş tamamlanamadı.']);
        if ($session['status'] !== 'complete' || !$session['user_id']) respond(['status'=>'pending']);

        $stmt = $pdo->prepare('SELECT id,name,email,role,avatar_url FROM users WHERE id=? LIMIT 1');
        $stmt->execute([(int)$session['user_id']]);
        $user = $stmt->fetch();
        if (!$user) fail('Kullanıcı hesabı bulunamadı.', 404);
        $user['id'] = (int)$user['id'];
        $token = createToken((int)$user['id']);
        $pdo->prepare('DELETE FROM google_login_sessions WHERE id=?')->execute([(int)$session['id']]);
        respond(['status'=>'complete','token'=>$token,'user'=>$user]);
    }

    if ($action === 'register' && $method === 'POST') {
        if (($config['ALLOW_PASSWORD_AUTH'] ?? false) !== true) fail('Şifreli kayıt kapalı. Google ile giriş kullanın.', 403);
        $name = trim((string)($input['name'] ?? ''));
        $email = cleanEmail((string)($input['email'] ?? ''));
        $password = (string)($input['password'] ?? '');
        if ($name === '' || mb_strlen($name) > 120) fail('Ad alanını kontrol edin.');
        if (strlen($password) < 8) fail('Şifre en az 8 karakter olmalı.');
        $role = isAdminEmail($email) ? 'admin' : 'tester';
        $stmt = db()->prepare('INSERT INTO users(name,email,password_hash,role,last_login_at) VALUES(?,?,?,?,NOW())');
        $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$role]);
        $id = (int)db()->lastInsertId();
        bindMemberships($id,$email);
        respond(['token'=>createToken($id),'user'=>['id'=>$id,'name'=>$name,'email'=>$email,'role'=>$role,'avatar_url'=>null]],201);
    }

    if ($action === 'login' && $method === 'POST') {
        if (($config['ALLOW_PASSWORD_AUTH'] ?? false) !== true) fail('Şifreli giriş kapalı. Google ile giriş kullanın.', 403);
        $email = cleanEmail((string)($input['email'] ?? ''));
        $stmt = db()->prepare('SELECT id,name,email,password_hash,role,avatar_url FROM users WHERE email=? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !$user['password_hash'] || !password_verify((string)($input['password'] ?? ''),(string)$user['password_hash'])) fail('E-posta veya şifre hatalı.',401);
        $user['id']=(int)$user['id'];
        bindMemberships((int)$user['id'],(string)$user['email']);
        db()->prepare('UPDATE users SET last_login_at=NOW() WHERE id=?')->execute([(int)$user['id']]);
        unset($user['password_hash']);
        respond(['token'=>createToken((int)$user['id']),'user'=>$user]);
    }

    if ($action === 'logout' && $method === 'POST') {
        currentUser();
        $token = bearerToken();
        if ($token) db()->prepare('DELETE FROM api_tokens WHERE token_hash=?')->execute([hash('sha256',$token)]);
        respond(['logged_out'=>true]);
    }

    if ($action === 'me') {
        respond(['user'=>currentUser()]);
    }

    if ($action === 'dashboard') {
        $u=currentUser(['admin']); $pdo=db();
        $q=$pdo->prepare('SELECT COUNT(*) FROM projects WHERE created_by=?'); $q->execute([$u['id']]); $projects=(int)$q->fetchColumn();
        $q=$pdo->prepare('SELECT COUNT(*) FROM project_members pm JOIN projects p ON p.id=pm.project_id WHERE p.created_by=?'); $q->execute([$u['id']]); $testers=(int)$q->fetchColumn();
        $q=$pdo->prepare('SELECT COUNT(*) FROM projects WHERE created_by=? AND test_start_date IS NOT NULL AND is_open=1'); $q->execute([$u['id']]); $active=(int)$q->fetchColumn();
        $q=$pdo->prepare('SELECT COUNT(*) FROM feedback f JOIN projects p ON p.id=f.project_id WHERE p.created_by=?'); $q->execute([$u['id']]); $feedback=(int)$q->fetchColumn();
        respond(['projects'=>$projects,'testers'=>$testers,'active_tests'=>$active,'feedback'=>$feedback]);
    }

    if ($action === 'projects') {
        $u=currentUser(); $pdo=db();
        if ($u['role'] === 'admin') {
            $stmt=$pdo->prepare("SELECT p.*, (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id=p.id) tester_count, (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id=p.id AND pm.status<>'invited') joined_count, (SELECT COUNT(*) FROM tester_groups g WHERE g.project_id=p.id) group_count FROM projects p WHERE p.created_by=? ORDER BY p.id DESC");
            $stmt->execute([$u['id']]);
        } else {
            $stmt=$pdo->prepare("SELECT p.*, (SELECT COUNT(*) FROM project_members x WHERE x.project_id=p.id) tester_count, (SELECT COUNT(*) FROM project_members x WHERE x.project_id=p.id AND x.status<>'invited') joined_count, (SELECT COUNT(*) FROM tester_groups g WHERE g.project_id=p.id) group_count FROM projects p LEFT JOIN project_members pm ON pm.project_id=p.id AND pm.user_id=? WHERE p.is_open=1 ORDER BY p.id DESC");
            $stmt->execute([$u['id']]);
        }
        $items=$stmt->fetchAll();
        foreach($items as &$p){
            if ($u['role'] !== 'admin') unset($p['opt_in_url']);
            $stats=projectStats((int)$p['id'],$p);
            $p['id']=(int)$p['id']; $p['tester_count']=(int)$p['tester_count']; $p['joined_count']=(int)$p['joined_count']; $p['group_count']=(int)$p['group_count'];
            $p['registered_count']=$stats['registered']; $p['missing_testers']=$stats['missing_testers']; $p['download_unlocked']=$stats['download_unlocked'];
            $p['elapsed_days']=$stats['elapsed_days']; $p['remaining_days']=$stats['remaining_days']; $p['test_duration_days']=(int)$p['test_duration_days']; $p['min_testers']=(int)$p['min_testers']; $p['is_open']=(bool)$p['is_open'];
        }
        respond(['projects'=>$items]);
    }

    if ($action === 'project_create' && $method === 'POST') {
        $u=currentUser(['admin']);
        $name=trim((string)($input['name']??'')); $package=trim((string)($input['package_name']??'')); $url=trim((string)($input['opt_in_url']??''));
        $groupName=trim((string)($input['group_name']??'Testçiler')); $groupEmail=cleanEmail((string)($input['google_group_email']??''));
        $min=max(1,(int)($input['min_testers']??12)); $duration=max(1,(int)($input['test_duration_days']??14));
        if($name==='' || mb_strlen($name)>160) fail('Proje adı gerekli.');
        if($package==='' || !preg_match('/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/',$package)) fail('Paket adı geçersiz.');
        if(!filter_var($url,FILTER_VALIDATE_URL) || !preg_match('#^https?://#i',$url)) fail('Kapalı test bağlantısı geçersiz.');
        if($groupName==='') $groupName='Testçiler';
        $emails=is_array($input['tester_emails']??null)?$input['tester_emails']:[];
        $pdo=db(); $pdo->beginTransaction();
        try {
            $q=$pdo->prepare('INSERT INTO projects(created_by,name,package_name,opt_in_url,min_testers,test_duration_days,is_open) VALUES(?,?,?,?,?,?,1)');
            $q->execute([$u['id'],$name,$package,$url,$min,$duration]); $projectId=(int)$pdo->lastInsertId();
            $q=$pdo->prepare('INSERT INTO tester_groups(project_id,name,google_group_email) VALUES(?,?,?)'); $q->execute([$projectId,$groupName,$groupEmail]); $groupId=(int)$pdo->lastInsertId();
            foreach(array_unique(array_map(fn($e)=>strtolower(trim((string)$e)),$emails)) as $rawEmail){
                if(!filter_var($rawEmail,FILTER_VALIDATE_EMAIL)) continue;
                $q=$pdo->prepare('SELECT id,name FROM users WHERE email=? LIMIT 1'); $q->execute([$rawEmail]); $found=$q->fetch(); $uid=$found?(int)$found['id']:null; $memberName=$found['name']??null;
                $q=$pdo->prepare("INSERT INTO project_members(project_id,user_id,email,name,status) VALUES(?,?,?,?, 'invited') ON DUPLICATE KEY UPDATE user_id=COALESCE(VALUES(user_id),user_id),name=COALESCE(VALUES(name),name)");
                $q->execute([$projectId,$uid,$rawEmail,$memberName]);
                $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND email=?'); $q->execute([$projectId,$rawEmail]); $memberId=(int)$q->fetchColumn();
                $q=$pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)'); $q->execute([$groupId,$memberId]);
            }
            $pdo->commit(); respond(['project_id'=>$projectId],201);
        } catch(Throwable $e){$pdo->rollBack();throw $e;}
    }

    if ($action === 'project_update' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); $project=requireOwner($projectId,(int)$u['id']);
        $name=trim((string)($input['name']??$project['name']));
        $package=trim((string)($input['package_name']??$project['package_name']));
        $url=trim((string)($input['opt_in_url']??$project['opt_in_url']));
        $min=max(1,(int)($input['min_testers']??$project['min_testers']));
        $duration=max(1,(int)($input['test_duration_days']??$project['test_duration_days']));
        $isOpen=array_key_exists('is_open',$input)?(($input['is_open']??false)?1:0):(int)$project['is_open'];
        if($name==='' || mb_strlen($name)>160) fail('Proje adı gerekli.');
        if($package==='' || !preg_match('/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/',$package)) fail('Paket adı geçersiz.');
        if(!filter_var($url,FILTER_VALIDATE_URL) || !preg_match('#^https?://#i',$url)) fail('Kapalı test bağlantısı geçersiz.');
        $q=db()->prepare('UPDATE projects SET name=?,package_name=?,opt_in_url=?,min_testers=?,test_duration_days=?,is_open=? WHERE id=?');
        $q->execute([$name,$package,$url,$min,$duration,$isOpen,$projectId]);
        respond(['updated'=>true]);
    }

    if ($action === 'project_detail') {
        $u=currentUser(['admin']); $id=(int)($_GET['id']??0); $project=requireOwner($id,(int)$u['id']); $pdo=db();
        $q=$pdo->prepare("SELECT g.*, (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id) member_count FROM tester_groups g WHERE g.project_id=? ORDER BY g.id"); $q->execute([$id]); $groups=$q->fetchAll();
        foreach($groups as &$g){$g['id']=(int)$g['id'];$g['member_count']=(int)$g['member_count'];}
        $q=$pdo->prepare('SELECT f.id,f.rating,f.message,f.created_at,u.name user_name,u.email user_email FROM feedback f JOIN users u ON u.id=f.user_id WHERE f.project_id=? ORDER BY f.id DESC LIMIT 100'); $q->execute([$id]); $feedback=$q->fetchAll();
        foreach($feedback as &$f){$f['id']=(int)$f['id'];$f['rating']=(int)$f['rating'];}
        $project['id']=(int)$project['id']; $project['min_testers']=(int)$project['min_testers']; $project['test_duration_days']=(int)$project['test_duration_days']; $project['is_open']=(bool)$project['is_open'];
        respond(['project'=>$project,'groups'=>$groups,'feedback'=>$feedback,'stats'=>projectStats($id,$project)]);
    }

    if ($action === 'group_create' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $name=trim((string)($input['name']??'')); $email=cleanEmail((string)($input['google_group_email']??'')); if($name==='') fail('Grup adı gerekli.');
        $q=db()->prepare('INSERT INTO tester_groups(project_id,name,google_group_email) VALUES(?,?,?)'); $q->execute([$projectId,$name,$email]); respond(['group_id'=>(int)db()->lastInsertId()],201);
    }

    if ($action === 'project_members') {
        $u=currentUser(['admin']); $projectId=(int)($_GET['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $page=max(1,(int)($_GET['page']??1)); $pageSize=max(20,min(100,(int)($_GET['page_size']??50))); $search=trim((string)($_GET['q']??'')); $offset=($page-1)*$pageSize;
        $where='project_id=?'; $params=[$projectId]; if($search!==''){ $where.=' AND (email LIKE ? OR name LIKE ?)'; $like='%'.$search.'%'; $params[]=$like; $params[]=$like; }
        $pdo=db(); $q=$pdo->prepare("SELECT COUNT(*) FROM project_members WHERE $where"); $q->execute($params); $total=(int)$q->fetchColumn();
        $q=$pdo->prepare("SELECT id,email,name,status,invited_at,joined_at,installed_at,completed_at,user_id FROM project_members WHERE $where ORDER BY id DESC LIMIT $pageSize OFFSET $offset"); $q->execute($params); $members=$q->fetchAll();
        foreach($members as &$m){$m['id']=(int)$m['id'];if($m['user_id']!==null)$m['user_id']=(int)$m['user_id'];}
        respond(['members'=>$members,'total'=>$total,'page'=>$page,'page_size'=>$pageSize,'has_more'=>($offset+count($members))<$total]);
    }

    if ($action === 'tester_add' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $email=cleanEmail((string)($input['email']??'')); $name=trim((string)($input['name']??'')); $pdo=db();
        $q=$pdo->prepare('SELECT id,name FROM users WHERE email=? LIMIT 1'); $q->execute([$email]); $found=$q->fetch(); $uid=$found?(int)$found['id']:null; if($name==='' && $found)$name=(string)$found['name'];
        $q=$pdo->prepare("INSERT INTO project_members(project_id,user_id,email,name,status) VALUES(?,?,?,?, 'invited') ON DUPLICATE KEY UPDATE user_id=COALESCE(VALUES(user_id),user_id),name=IF(VALUES(name)='',name,VALUES(name))"); $q->execute([$projectId,$uid,$email,$name?:null]);
        $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND email=?'); $q->execute([$projectId,$email]); $memberId=(int)$q->fetchColumn();
        if(isset($input['group_id'])){$groupId=(int)$input['group_id'];$g=$pdo->prepare('SELECT id FROM tester_groups WHERE id=? AND project_id=?');$g->execute([$groupId,$projectId]);if(!$g->fetch())fail('Grup bulunamadı.',404);$g=$pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)');$g->execute([$groupId,$memberId]);}
        respond(['member_id'=>$memberId],201);
    }

    if ($action === 'tester_bulk_add' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $emails=is_array($input['emails']??null)?$input['emails']:[]; if(!$emails) fail('E-posta listesi boş.'); $groupId=isset($input['group_id'])?(int)$input['group_id']:null; $pdo=db();
        if($groupId!==null){$g=$pdo->prepare('SELECT id FROM tester_groups WHERE id=? AND project_id=?');$g->execute([$groupId,$projectId]);if(!$g->fetch())fail('Grup bulunamadı.',404);}
        $processed=0; $pdo->beginTransaction();
        try {
            foreach(array_unique(array_map(fn($e)=>strtolower(trim((string)$e)),$emails)) as $email){
                if(!filter_var($email,FILTER_VALIDATE_EMAIL)) continue;
                $q=$pdo->prepare('SELECT id,name FROM users WHERE email=? LIMIT 1');$q->execute([$email]);$found=$q->fetch();$uid=$found?(int)$found['id']:null;$memberName=$found['name']??null;
                $q=$pdo->prepare("INSERT INTO project_members(project_id,user_id,email,name,status) VALUES(?,?,?,?, 'invited') ON DUPLICATE KEY UPDATE user_id=COALESCE(VALUES(user_id),user_id),name=COALESCE(VALUES(name),name)");$q->execute([$projectId,$uid,$email,$memberName]);
                $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND email=?');$q->execute([$projectId,$email]);$memberId=(int)$q->fetchColumn();
                if($groupId!==null){$g=$pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)');$g->execute([$groupId,$memberId]);}
                $processed++;
            }
            $pdo->commit(); respond(['processed'=>$processed],201);
        } catch(Throwable $e){$pdo->rollBack();throw $e;}
    }

    if ($action === 'project_start' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); $project=requireOwner($projectId,(int)$u['id']);
        requireDownloadUnlocked($projectId,$project);
        db()->prepare('UPDATE projects SET test_start_date=COALESCE(test_start_date,CURDATE()) WHERE id=?')->execute([$projectId]); respond(['started'=>true]);
    }

    if ($action === 'tester_tasks') {
        $u=currentUser(['tester','admin']); $pdo=db();
        $q=$pdo->prepare("SELECT p.id project_id,p.name,p.package_name,p.test_start_date,p.test_duration_days,p.min_testers,pm.status,(SELECT COUNT(*) FROM project_members x WHERE x.project_id=p.id) tester_count,(SELECT COUNT(user_id) FROM project_members x WHERE x.project_id=p.id) registered_count,(SELECT COUNT(*) FROM project_members x WHERE x.project_id=p.id AND x.status<>'invited') joined_count FROM projects p LEFT JOIN project_members pm ON pm.project_id=p.id AND pm.user_id=? WHERE p.is_open=1 ORDER BY p.id DESC");
        $q->execute([$u['id']]); $rows=$q->fetchAll();
        foreach($rows as &$r){
            $project=['test_start_date'=>$r['test_start_date'],'test_duration_days'=>$r['test_duration_days']]; $stats=projectStats((int)$r['project_id'],$project);
            $r['project_id']=(int)$r['project_id'];$r['test_duration_days']=(int)$r['test_duration_days'];$r['min_testers']=(int)$r['min_testers'];$r['tester_count']=(int)$r['tester_count'];$r['registered_count']=(int)$r['registered_count'];$r['joined_count']=(int)$r['joined_count'];
            $r['status']=$r['status'] ?: 'available';$r['missing_testers']=$stats['missing_testers'];$r['download_unlocked']=$stats['download_unlocked'];$r['elapsed_days']=$stats['elapsed_days'];$r['remaining_days']=$stats['remaining_days'];
        }
        respond(['tasks'=>$rows]);
    }

    if ($action === 'tester_enroll' && $method === 'POST') {
        $u=currentUser(['tester','admin']); $projectId=(int)($input['project_id']??0); $project=getOpenProject($projectId); $memberId=enrollUserInProject($u,$projectId); $stats=projectStats($projectId,$project);
        respond(['member_id'=>$memberId,'status'=>'invited','registered_count'=>$stats['registered'],'minimum_testers'=>$stats['minimum_testers'],'missing_testers'=>$stats['missing_testers'],'download_unlocked'=>$stats['download_unlocked']]);
    }

    if ($action === 'tester_open_link' && $method === 'POST') {
        $u=currentUser(['tester','admin']); $projectId=(int)($input['project_id']??0); $project=getOpenProject($projectId); enrollUserInProject($u,$projectId); $stats=requireDownloadUnlocked($projectId,$project);
        respond(['opt_in_url'=>(string)$project['opt_in_url'],'registered_count'=>$stats['registered'],'minimum_testers'=>$stats['minimum_testers']]);
    }

    if ($action === 'tester_status' && $method === 'POST') {
        $u=currentUser(['tester','admin']); $projectId=(int)($input['project_id']??0); $status=(string)($input['status']??'');
        $allowed=['joined','installed','testing','completed']; if(!in_array($status,$allowed,true)) fail('Geçersiz durum.');
        $project=getOpenProject($projectId); $memberId=enrollUserInProject($u,$projectId); requireDownloadUnlocked($projectId,$project); $pdo=db(); $timeColumn=['joined'=>'joined_at','installed'=>'installed_at','completed'=>'completed_at'][$status]??null;
        if($timeColumn){$q=$pdo->prepare("UPDATE project_members SET status=?, $timeColumn=COALESCE($timeColumn,NOW()) WHERE id=?");}else{$q=$pdo->prepare('UPDATE project_members SET status=? WHERE id=?');}
        $q->execute([$status,$memberId]); $q=$pdo->prepare('INSERT INTO test_events(project_id,project_member_id,event_type) VALUES(?,?,?)'); $q->execute([$projectId,$memberId,$status]);
        respond(['status'=>$status]);
    }

    if ($action === 'feedback_create' && $method === 'POST') {
        $u=currentUser(['tester','admin']); $projectId=(int)($input['project_id']??0); $rating=max(1,min(5,(int)($input['rating']??5))); $message=trim((string)($input['message']??'')); if($message==='') fail('Geri bildirim boş olamaz.');
        enrollUserInProject($u,$projectId); $q=db()->prepare('INSERT INTO feedback(project_id,user_id,rating,message) VALUES(?,?,?,?)'); $q->execute([$projectId,$u['id'],$rating,$message]); respond(['feedback_id'=>(int)db()->lastInsertId()],201);
    }

    fail('İşlem bulunamadı.',404);
} catch (PDOException $e) {
    if ((int)$e->getCode() === 23000) fail('Bu kayıt zaten mevcut.',409);
    fail('Veritabanı işlemi tamamlanamadı.',500);
} catch (Throwable $e) {
    fail('Sunucu hatası: ' . $e->getMessage(),500);
}
