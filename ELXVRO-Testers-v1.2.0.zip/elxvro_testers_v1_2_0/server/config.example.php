<?php
// ELXVRO Testers server configuration.
// Fill these values before uploading to hosting.
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'CPANEL_DB_NAME',
    'DB_USER' => 'CPANEL_DB_USER',
    'DB_PASS' => 'DB_PASSWORD',

    // Google Cloud Console > OAuth 2.0 Client IDs > Web application.
    'GOOGLE_CLIENT_ID' => 'YOUR_CLIENT_ID.apps.googleusercontent.com',
    'GOOGLE_CLIENT_SECRET' => 'YOUR_CLIENT_SECRET',

    // This exact URL must also be added to "Authorized redirect URIs" in Google Cloud.
    'GOOGLE_REDIRECT_URI' => 'https://example.com/elxvro-testers/api/index.php?action=google_callback',

    // These Google accounts become app administrators automatically.
    // Friends/testers do not go here.
    'ADMIN_EMAILS' => [
        'elxvro@gmail.com',
    ],

    'TOKEN_DAYS' => 90,

    // Kept only for backwards compatibility with v1.0 API. The v1.1 app uses Google only.
    'ALLOW_PASSWORD_AUTH' => false,
    'ADMIN_SETUP_KEY' => 'CHANGE_ME_LONG_RANDOM_KEY',
];
