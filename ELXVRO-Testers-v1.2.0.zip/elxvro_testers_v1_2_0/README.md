# ELXVRO Testers v1.2.0

## Yeni: minimum testçi gelmeden Google Play bağlantısı açılmaz

Bu sürümde testçi önce ELXVRO Testers içindeki projeye katılır. Projede Google hesabıyla eşleşmiş kayıtlı testçi sayısı `min_testers` eşiğine ulaşmadan Google Play kapalı test bağlantısı tester API'sinden verilmez ve uygulamadaki indirme/katılım düğmesi kilitli kalır. Eşik proje bazında ayarlanabilir; uygulama tarafında testçi veya grup için üst sınır yoktur.

Ek olarak proje düzenleme, indirme kilidi ilerlemesi ve kilit tamamlanmadan 14 günlük takibi başlatmayı engelleyen sunucu kontrolü eklendi.

### Güncelleme

- GitHub Actions workflow dosyasını değiştirmeyin.
- Flutter proje dosyalarını GitHub'a yükleyip mevcut sabit workflow ile APK oluşturun.
- Hostingde `server/api/index.php` dosyasını v1.2.0 sürümüyle değiştirin.
- `server/config.php` dosyanızdaki çalışan MySQL/Google OAuth ayarlarını koruyun.
- Veritabanı şema değişikliği gerekmez.

---

# ELXVRO Testers v1.1.0

Kendi arkadaş/testçi topluluğunuzla Google Play kapalı test süreçlerini organize etmek için Flutter + PHP + MySQL uygulaması.

## v1.1.0 ile gelenler

- Google ile giriş
- İlk Google girişinde MySQL'e otomatik kullanıcı kaydı
- Ayrı kayıt formu ve uygulama şifresi yok
- `ADMIN_EMAILS` ile otomatik yönetici yetkisi
- Arkadaşlar için otomatik testçi hesabı
- Testçilerin açık projeleri doğrudan görmesi
- `Teste Katıl` ile uygulama içi otomatik proje üyeliği
- Google Play kapalı test bağlantısını dışarıda açma
- `Katıldım / Yükledim / Test ediyorum / Tamamladım` durumları
- 14 günlük süreç göstergesi
- Kalan gün göstergesi
- Proje toplam testçi ve katılan testçi sayısı
- 1–5 puan + yazılı geri bildirim
- Yönetici tarafında proje, grup, testçi ve geri bildirim takibi
- Testçi ve grup sayısında uygulama kaynaklı üst sınır yok
- Büyük testçi listelerinde arama ve sayfalama

## Google giriş mimarisi

Google girişi sunucu taraflı Web OAuth kullanır. Android uygulaması Google'ın güvenli giriş sayfasını açar; PHP API OAuth sonucunu doğrular ve uygulama kısa süreli giriş oturumunu API üzerinden tamamlar.

Bunun avantajı: Android Google OAuth SHA-1 / release keystore bağımlılığı yoktur. **Çalışan GitHub Actions APK workflow'unu değiştirmeye gerek yoktur.**

## Kurulum sırası

1. `server/README_DEPLOY.md` dosyasındaki cPanel + MySQL + Google OAuth adımlarını uygula.
2. Yeni veritabanıysa `server/database/schema.sql` içeri aktar.
3. v1.0 veritabanın varsa yalnızca `server/database/migrate_v1_0_to_v1_1.sql` çalıştır.
4. `server/config.php` içindeki DB, Google OAuth ve `ADMIN_EMAILS` alanlarını doldur.
5. `lib/core/app_config.dart` içindeki API adresini kendi alan adına göre değiştir.
6. Proje dosyalarını GitHub'a yükle.
7. Daha önce çalışan `.github/workflows/elxvro-testers-build.yml` dosyanı **aynen bırak**.
8. Build tamamlanınca APK artifact'ını indirip kur.

## Test mantığı

12 kişi uygulamadaki bir üst sınır değildir. Projede `min_testers=12` yalnızca minimum hedef göstergesidir. 12, 20, 50, 100 veya daha fazla testçi eklenebilir. Uygulama/MySQL tarafında sabit testçi veya grup limiti uygulanmaz; pratik kapasite hosting kaynaklarına bağlıdır.

## Resmi Google Play durumu

Uygulamadaki katılım, yükleme ve tamamlanma işaretleri ekip içi takip içindir. Google Play kapalı testinin resmi kayıtları ve şartları Play Console tarafındadır.
