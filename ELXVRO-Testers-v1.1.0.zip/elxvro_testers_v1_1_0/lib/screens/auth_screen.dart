import 'package:flutter/material.dart';

import '../core/session_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key, required this.session});
  final SessionController session;

  Future<void> _login(BuildContext context) async {
    try {
      await session.signInWithGoogle();
    } catch (e) {
      if (context.mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Row(
                    children: [
                      ElxvroLogo(size: 54),
                      SizedBox(width: 14),
                      Text('ELXVRO Testers', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                    ],
                  ),
                  const SizedBox(height: 46),
                  const Text('Kapalı testleri tek yerde yönet', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, height: 1.08)),
                  const SizedBox(height: 12),
                  const Text(
                    'Google hesabınla giriş yap. İlk girişte hesabın otomatik oluşturulur; ayrı kayıt formu veya şifre yoktur.',
                    style: TextStyle(color: AppTheme.muted, fontSize: 16, height: 1.5),
                  ),
                  const SizedBox(height: 28),
                  const SectionCard(
                    child: Column(
                      children: [
                        _Feature(icon: Icons.groups_rounded, title: 'Sınırsız testçi ve grup', subtitle: '12 kişi yalnızca minimum takip göstergesidir.'),
                        SizedBox(height: 18),
                        _Feature(icon: Icons.open_in_new_rounded, title: 'Tek dokunuşla teste katıl', subtitle: 'Kapalı test bağlantısını doğrudan Google Play’de aç.'),
                        SizedBox(height: 18),
                        _Feature(icon: Icons.timer_outlined, title: '14 günlük süreç takibi', subtitle: 'Geçen gün, kalan gün ve testçi durumlarını izle.'),
                        SizedBox(height: 18),
                        _Feature(icon: Icons.forum_outlined, title: 'Geri bildirim', subtitle: 'Testçiler puan ve yorum gönderebilir.'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  AnimatedBuilder(
                    animation: session,
                    builder: (context, _) {
                      final busy = session.googleLoginInProgress;
                      return FilledButton(
                        onPressed: busy ? null : () => _login(context),
                        style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black87),
                        child: busy
                            ? const SizedBox.square(dimension: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black54))
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircleAvatar(radius: 13, backgroundColor: Color(0xFFF1F5F9), child: Text('G', style: TextStyle(color: Color(0xFF4285F4), fontWeight: FontWeight.w900))),
                                  SizedBox(width: 12),
                                  Text('Google ile devam et', style: TextStyle(fontWeight: FontWeight.w800)),
                                ],
                              ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Giriş güvenli Google sayfasında açılır. Uygulama Google şifrenizi görmez veya saklamaz.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.4),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(color: AppTheme.primary.withValues(alpha: .12), borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: AppTheme.primary),
        ),
        const SizedBox(width: 13),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 3),
              Text(subtitle, style: const TextStyle(color: AppTheme.muted, fontSize: 13, height: 1.35)),
            ],
          ),
        ),
      ],
    );
  }
}
