import 'package:flutter/material.dart';

import '../core/session_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'admin/admin_dashboard_screen.dart';
import 'tester/tester_dashboard_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.session});
  final SessionController session;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final user = widget.session.user!;
    final pages = <Widget>[
      user.isAdmin ? AdminDashboardScreen(session: widget.session) : TesterDashboardScreen(session: widget.session),
      _Profile(session: widget.session),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        backgroundColor: AppTheme.panel,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'Panel'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profil'),
        ],
      ),
    );
  }
}

class _Profile extends StatelessWidget {
  const _Profile({required this.session});
  final SessionController session;

  @override
  Widget build(BuildContext context) {
    final user = session.user!;
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [ElxvroLogo(size: 34), SizedBox(width: 10), Text('Profil')]),
        actions: [IconButton(onPressed: session.logout, icon: const Icon(Icons.logout_rounded), tooltip: 'Çıkış yap')],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          SectionCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                _Avatar(name: user.name, url: user.avatarUrl),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(user.name, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text(user.email, style: const TextStyle(color: AppTheme.muted)),
                  ]),
                ),
              ]),
              const SizedBox(height: 16),
              Wrap(spacing: 8, runSpacing: 8, children: [
                StatusPill(user.isAdmin ? 'Yönetici' : 'Testçi'),
                const StatusPill('Google hesabı', color: AppTheme.success),
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          const SectionCard(
            child: Text(
              'ELXVRO Testers; kapalı test bağlantılarını, testçi durumlarını, 14 günlük ilerlemeyi ve geri bildirimleri düzenler. Google Play tarafındaki gerçek test katılımı resmi kayıttır.',
              style: TextStyle(color: AppTheme.muted, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.name, this.url});
  final String name;
  final String? url;

  @override
  Widget build(BuildContext context) {
    final initial = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
    if (url != null && url!.isNotEmpty) {
      return CircleAvatar(
        radius: 31,
        backgroundColor: AppTheme.panel2,
        foregroundImage: NetworkImage(url!),
        child: Text(initial),
      );
    }
    return CircleAvatar(radius: 31, backgroundColor: AppTheme.panel2, child: Text(initial, style: const TextStyle(fontWeight: FontWeight.w900)));
  }
}
