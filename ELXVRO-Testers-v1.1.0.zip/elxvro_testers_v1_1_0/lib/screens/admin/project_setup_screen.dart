import 'package:flutter/material.dart';

import '../../core/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';

class ProjectSetupScreen extends StatefulWidget {
  const ProjectSetupScreen({super.key, required this.session});
  final SessionController session;

  @override
  State<ProjectSetupScreen> createState() => _ProjectSetupScreenState();
}

class _ProjectSetupScreenState extends State<ProjectSetupScreen> {
  final _page = PageController();
  final _name = TextEditingController();
  final _package = TextEditingController();
  final _groupName = TextEditingController(text: 'ELXVRO Testers');
  final _groupEmail = TextEditingController();
  final _link = TextEditingController();
  final _testerEmails = TextEditingController();
  int _step = 0;
  bool _busy = false;

  @override
  void dispose() {
    _page.dispose();
    _name.dispose();
    _package.dispose();
    _groupName.dispose();
    _groupEmail.dispose();
    _link.dispose();
    _testerEmails.dispose();
    super.dispose();
  }

  List<String> get _emails => _testerEmails.text
      .split(RegExp(r'[\n,; ]+'))
      .map((e) => e.trim().toLowerCase())
      .where((e) => e.contains('@'))
      .toSet()
      .toList();

  bool _validateStep() {
    switch (_step) {
      case 0:
        return _name.text.trim().isNotEmpty && _package.text.trim().contains('.') && _groupEmail.text.trim().contains('@');
      case 1:
        return Uri.tryParse(_link.text.trim())?.hasScheme == true && _link.text.startsWith('http');
      default:
        return true;
    }
  }

  Future<void> _next() async {
    if (!_validateStep()) {
      showError(context, 'Bu adım için gerekli alanları kontrol edin.');
      return;
    }
    if (_step < 3) {
      setState(() => _step++);
      await _page.animateToPage(_step, duration: const Duration(milliseconds: 260), curve: Curves.easeOutCubic);
      return;
    }
    setState(() => _busy = true);
    try {
      await widget.session.api.post('project_create', {
        'name': _name.text.trim(),
        'package_name': _package.text.trim(),
        'opt_in_url': _link.text.trim(),
        'group_name': _groupName.text.trim(),
        'google_group_email': _groupEmail.text.trim(),
        'tester_emails': _emails,
        'min_testers': 12,
        'test_duration_days': 14,
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _back() async {
    if (_step == 0) {
      Navigator.pop(context);
      return;
    }
    setState(() => _step--);
    await _page.animateToPage(_step, duration: const Duration(milliseconds: 240), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
            child: Row(children: [
              const ElxvroLogo(size: 38),
              const SizedBox(width: 10),
              const Text('ELXVRO Testers', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
              const Spacer(),
              SizedBox(
                width: 116,
                child: Row(children: List.generate(4, (i) => Expanded(child: Container(height: 6, margin: const EdgeInsets.symmetric(horizontal: 3), decoration: BoxDecoration(color: i <= _step ? AppTheme.primary : AppTheme.line, borderRadius: BorderRadius.circular(99)))))),
              ),
              const SizedBox(width: 10),
              Text('${_step + 1}/4', style: const TextStyle(color: AppTheme.muted)),
            ]),
          ),
          Expanded(
            child: PageView(
              controller: _page,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _step1(),
                _step2(),
                _step3(),
                _step4(),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              SizedBox(width: 58, height: 54, child: OutlinedButton(onPressed: _busy ? null : _back, child: const Icon(Icons.arrow_back_rounded))),
              const SizedBox(width: 12),
              Expanded(child: FilledButton(onPressed: _busy ? null : _next, child: _busy ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(_step == 3 ? 'Projeyi oluştur' : 'İleri'))),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _pageScaffold({required String kicker, required String title, required String subtitle, required List<Widget> children}) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 18),
      children: [
        Text(kicker, style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, height: 1.1)),
        const SizedBox(height: 9),
        Text(subtitle, style: const TextStyle(color: AppTheme.muted, fontSize: 16, height: 1.4)),
        const SizedBox(height: 24),
        ...children,
      ],
    );
  }

  Widget _step1() => _pageScaffold(
        kicker: 'Adım 1',
        title: 'Testçi Grubu Ekle',
        subtitle: 'Google Play kapalı testinde kullanacağın Google Grubu’nu projeye bağla.',
        children: [
          SectionCard(child: Column(children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Uygulama / oyun adı', hintText: 'ELXVRO Game')),
            const SizedBox(height: 12),
            TextField(controller: _package, decoration: const InputDecoration(labelText: 'Paket adı', hintText: 'com.elxvro.game')),
            const SizedBox(height: 12),
            TextField(controller: _groupName, decoration: const InputDecoration(labelText: 'Grup adı')),
            const SizedBox(height: 12),
            TextField(controller: _groupEmail, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Google Grup e-posta adresi', hintText: 'elxvro-testers@googlegroups.com')),
          ])),
          const SizedBox(height: 14),
          const SectionCard(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded, color: AppTheme.primary), SizedBox(width: 12), Expanded(child: Text('Play Console > Kapalı test > Kanalı yönet > Test edenler > Google Grupları ekle', style: TextStyle(color: AppTheme.muted, height: 1.45)))])),
        ],
      );

  Widget _step2() => _pageScaffold(
        kicker: 'Adım 2',
        title: 'Test Bağlantısını Ekle',
        subtitle: 'Play Console’un verdiği kapalı test katılım bağlantısını ekle.',
        children: [
          SectionCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.link_rounded, color: AppTheme.primary), SizedBox(width: 10), Text('Kapalı test bağlantısı', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))]),
            const SizedBox(height: 16),
            TextField(controller: _link, keyboardType: TextInputType.url, minLines: 2, maxLines: 3, decoration: const InputDecoration(hintText: 'https://play.google.com/apps/testing/com.elxvro.game')),
          ])),
          const SizedBox(height: 14),
          const SectionCard(child: Text('Bu bağlantı testçilere “Teste Katıl” düğmesiyle açılır. Testçi Google hesabıyla Play Store’da katılımı tamamlar.', style: TextStyle(color: AppTheme.muted, height: 1.5))),
        ],
      );

  Widget _step3() => _pageScaffold(
        kicker: 'Adım 3',
        title: 'Testçileri Davet Et',
        subtitle: 'Bu adım isteğe bağlı. Arkadaşların Google ile giriş yaptığında açık testleri görüp kendileri katılabilir; istersen e-postaları önceden de ekleyebilirsin.',
        children: [
          SectionCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(
              controller: _testerEmails,
              minLines: 8,
              maxLines: 14,
              keyboardType: TextInputType.multiline,
              decoration: const InputDecoration(labelText: 'Testçi e-postaları', hintText: 'ali@gmail.com\nayse@gmail.com\nmehmet@gmail.com'),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 12),
            Text('${_emails.length} geçerli e-posta algılandı', style: const TextStyle(color: AppTheme.muted)),
          ])),
          const SizedBox(height: 14),
          const SectionCard(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.all_inclusive_rounded, color: AppTheme.success), SizedBox(width: 12), Expanded(child: Text('Testçi veya grup sayısı için yapay bir sınır yoktur. Açık projelerde uygulamaya Google ile giriş yapan arkadaşların kendileri de teste eklenebilir.', style: TextStyle(color: AppTheme.muted, height: 1.4)))])),
        ],
      );

  Widget _step4() => _pageScaffold(
        kicker: 'Adım 4',
        title: 'Süreç Takibi',
        subtitle: 'Projeyi oluşturduktan sonra katılımı, yüklemeyi, geri bildirimleri ve 14 günlük ilerlemeyi takip et.',
        children: [
          SectionCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Kurulum özeti', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            _reviewRow('Proje', _name.text.trim()),
            _reviewRow('Paket', _package.text.trim()),
            _reviewRow('Google Grubu', _groupEmail.text.trim()),
            _reviewRow('İlk testçiler', '${_emails.length} kişi'),
            _reviewRow('Takip eşiği', '12 testçi (minimum gösterge)'),
            _reviewRow('Takip süresi', '14 gün'),
          ])),
          const SizedBox(height: 14),
          const SectionCard(child: Text('14 günlük sayaç yönetici tarafından “Testi başlat” denildiğinde başlar. Bu sayaç organizasyon amaçlıdır; resmi süre ve uygunluk Play Console kayıtlarına göre değerlendirilir.', style: TextStyle(color: AppTheme.muted, height: 1.5))),
        ],
      );

  Widget _reviewRow(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 13),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 110, child: Text(label, style: const TextStyle(color: AppTheme.muted))),
          Expanded(child: Text(value.isEmpty ? '—' : value, style: const TextStyle(fontWeight: FontWeight.w700))),
        ]),
      );
}
