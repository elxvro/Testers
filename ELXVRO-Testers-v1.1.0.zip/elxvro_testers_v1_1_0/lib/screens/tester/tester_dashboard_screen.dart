import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';

class TesterDashboardScreen extends StatefulWidget {
  const TesterDashboardScreen({super.key, required this.session});
  final SessionController session;

  @override
  State<TesterDashboardScreen> createState() => _TesterDashboardScreenState();
}

class _TesterDashboardScreenState extends State<TesterDashboardScreen> {
  bool _loading = true;
  final Set<int> _busyProjects = {};
  List<dynamic> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await widget.session.api.get('tester_tasks') as Map<String, dynamic>;
      if (mounted) setState(() => _tasks = data['tasks'] as List<dynamic>? ?? []);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _withBusy(int projectId, Future<void> Function() action) async {
    if (_busyProjects.contains(projectId)) return;
    setState(() => _busyProjects.add(projectId));
    try {
      await action();
    } finally {
      if (mounted) setState(() => _busyProjects.remove(projectId));
    }
  }

  Future<void> _mark(int projectId, String status) async {
    await _withBusy(projectId, () async {
      try {
        await widget.session.api.post('tester_status', {'project_id': projectId, 'status': status});
        await _load();
      } catch (e) {
        if (mounted) showError(context, e);
      }
    });
  }

  Future<void> _join(Map<String, dynamic> task) async {
    final projectId = (task['project_id'] as num).toInt();
    await _withBusy(projectId, () async {
      try {
        await widget.session.api.post('tester_enroll', {'project_id': projectId});
        final url = Uri.tryParse(task['opt_in_url'] as String? ?? '');
        if (url == null || !await launchUrl(url, mode: LaunchMode.externalApplication)) {
          throw Exception('Google Play test bağlantısı açılamadı.');
        }
        await _load();
      } catch (e) {
        if (mounted) showError(context, e);
      }
    });
  }

  Future<void> _feedback(int projectId) async {
    final message = TextEditingController();
    int rating = 5;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Geri bildirim gönder'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<int>(
                initialValue: rating,
                decoration: const InputDecoration(labelText: 'Puan'),
                items: [1, 2, 3, 4, 5].map((n) => DropdownMenuItem(value: n, child: Text('$n / 5'))).toList(),
                onChanged: (v) => setLocal(() => rating = v ?? 5),
              ),
              const SizedBox(height: 12),
              TextField(controller: message, minLines: 4, maxLines: 7, decoration: const InputDecoration(labelText: 'Yorum / hata / öneri')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Gönder')),
          ],
        ),
      ),
    );
    if (ok != true || message.text.trim().isEmpty) return;
    try {
      await widget.session.api.post('feedback_create', {'project_id': projectId, 'rating': rating, 'message': message.text.trim()});
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Geri bildirim gönderildi.')));
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      message.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [ElxvroLogo(size: 34), SizedBox(width: 10), Text('Test Görevlerim')]),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 40),
                children: [
                  Text('Merhaba, ${widget.session.user!.name}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  const Text('Açık kapalı-test görevlerini burada görebilir ve tek dokunuşla katılabilirsin.', style: TextStyle(color: AppTheme.muted, height: 1.45)),
                  const SizedBox(height: 22),
                  if (_tasks.isEmpty)
                    const SectionCard(
                      child: Text('Şu anda yayınlanmış test görevi yok.', style: TextStyle(color: AppTheme.muted, height: 1.5)),
                    )
                  else
                    ..._tasks.map((raw) => _taskCard(raw as Map<String, dynamic>)),
                  const SizedBox(height: 8),
                  const Text(
                    'Buradaki “Katıldım / Yükledim” durumları ekip içi takip içindir. Google Play ve Play Console kayıtları resmi test kaynağıdır.',
                    style: TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.4),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _taskCard(Map<String, dynamic> t) {
    final status = t['status'] as String? ?? 'available';
    final id = (t['project_id'] as num).toInt();
    final busy = _busyProjects.contains(id);
    final elapsed = (t['elapsed_days'] as num?)?.toInt() ?? 0;
    final duration = (t['test_duration_days'] as num?)?.toInt() ?? 14;
    final remaining = (t['remaining_days'] as num?)?.toInt() ?? duration;
    final started = t['test_start_date'] != null;
    final joined = (t['joined_count'] as num?)?.toInt() ?? 0;
    final total = (t['tester_count'] as num?)?.toInt() ?? 0;
    final minTesters = (t['min_testers'] as num?)?.toInt() ?? 12;
    final progress = duration <= 0 ? 0.0 : (elapsed / duration).clamp(0, 1).toDouble();

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: SectionCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const ElxvroLogo(size: 46),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t['name'] as String? ?? '', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                const SizedBox(height: 3),
                Text(t['package_name'] as String? ?? '', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
              ]),
            ),
            StatusPill(_statusText(status), color: _statusColor(status)),
          ]),
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: [
            StatusPill('$joined / $total katıldı', color: AppTheme.success),
            StatusPill('Minimum $minTesters'),
          ]),
          const SizedBox(height: 16),
          if (started) ...[
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Gün $elapsed / $duration', style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(remaining > 0 ? '$remaining gün kaldı' : 'Süre tamamlandı', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
            ]),
            const SizedBox(height: 9),
            LinearProgressIndicator(value: progress, minHeight: 9, borderRadius: BorderRadius.circular(99)),
            const SizedBox(height: 16),
          ] else ...[
            const Row(children: [
              Icon(Icons.schedule_rounded, size: 18, color: AppTheme.muted),
              SizedBox(width: 8),
              Text('14 günlük takip henüz başlatılmadı.', style: TextStyle(color: AppTheme.muted, fontSize: 13)),
            ]),
            const SizedBox(height: 16),
          ],
          FilledButton.icon(
            onPressed: busy ? null : () => _join(t),
            icon: const Icon(Icons.open_in_new_rounded),
            label: Text(status == 'available' ? 'Teste Katıl' : 'Google Play test sayfasını aç'),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: busy ? null : () => _mark(id, 'joined'), child: const Text('Katıldım'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: busy ? null : () => _mark(id, 'installed'), child: const Text('Yükledim'))),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: busy ? null : () => _mark(id, 'testing'), child: const Text('Test ediyorum'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: busy ? null : () => _mark(id, 'completed'), child: const Text('Tamamladım'))),
          ]),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: status == 'available' ? null : () => _feedback(id),
            icon: const Icon(Icons.chat_bubble_outline_rounded),
            label: const Text('Geri bildirim gönder'),
          ),
        ]),
      ),
    );
  }

  String _statusText(String status) {
    const map = {
      'available': 'Katılıma açık',
      'invited': 'Henüz katılmadın',
      'joined': 'Katıldın',
      'installed': 'Yüklendi',
      'testing': 'Test ediliyor',
      'completed': 'Tamamlandı',
    };
    return map[status] ?? status;
  }

  Color _statusColor(String status) {
    if (status == 'completed' || status == 'installed' || status == 'testing' || status == 'joined') return AppTheme.success;
    return AppTheme.primary;
  }
}
