class AppConfig {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://YOUR-DOMAIN.com/elxvro-testers/api/index.php',
  );

  static const String appName = 'ELXVRO Testers';
  static const Duration apiTimeout = Duration(seconds: 20);
  static const Duration googlePollInterval = Duration(seconds: 2);
  static const Duration googleLoginTimeout = Duration(minutes: 3);
}
