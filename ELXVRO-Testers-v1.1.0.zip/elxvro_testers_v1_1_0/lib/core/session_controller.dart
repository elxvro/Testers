import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/app_user.dart';
import 'api_client.dart';
import 'app_config.dart';

class SessionController extends ChangeNotifier {
  SessionController() : api = ApiClient();

  final ApiClient api;
  AppUser? user;
  bool restoring = true;
  bool googleLoginInProgress = false;

  bool get signedIn => user != null;

  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    api.token = prefs.getString('auth_token');
    if (api.token != null) {
      try {
        final data = await api.get('me') as Map<String, dynamic>;
        user = AppUser.fromJson(data['user'] as Map<String, dynamic>);
      } catch (_) {
        api.token = null;
        await prefs.remove('auth_token');
      }
    }
    restoring = false;
    notifyListeners();
  }

  Future<void> signInWithGoogle() async {
    if (googleLoginInProgress) return;
    googleLoginInProgress = true;
    notifyListeners();

    try {
      final begin = await api.post('google_begin', {}) as Map<String, dynamic>;
      final sessionId = begin['session_id'] as String? ?? '';
      final authUrl = Uri.tryParse(begin['auth_url'] as String? ?? '');
      if (sessionId.isEmpty || authUrl == null) {
        throw const ApiException('Google giriş oturumu başlatılamadı.');
      }

      final opened = await launchUrl(authUrl, mode: LaunchMode.externalApplication);
      if (!opened) {
        throw const ApiException('Google giriş sayfası açılamadı.');
      }

      final deadline = DateTime.now().add(AppConfig.googleLoginTimeout);
      while (DateTime.now().isBefore(deadline)) {
        await Future<void>.delayed(AppConfig.googlePollInterval);
        final result = await api.post('google_poll', {'session_id': sessionId}) as Map<String, dynamic>;
        final status = result['status'] as String? ?? 'pending';

        if (status == 'complete') {
          await _acceptAuth(result);
          return;
        }
        if (status == 'failed') {
          throw ApiException(result['message'] as String? ?? 'Google ile giriş tamamlanamadı.');
        }
      }

      throw const ApiException('Google giriş süresi doldu. Tekrar deneyin.');
    } finally {
      googleLoginInProgress = false;
      notifyListeners();
    }
  }

  Future<void> _acceptAuth(Map<String, dynamic> data) async {
    final token = data['token'] as String?;
    final rawUser = data['user'];
    if (token == null || token.isEmpty || rawUser is! Map<String, dynamic>) {
      throw const ApiException('Oturum bilgisi alınamadı.');
    }

    api.token = token;
    user = AppUser.fromJson(rawUser);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    notifyListeners();
  }

  Future<void> logout() async {
    try {
      await api.post('logout', {});
    } catch (_) {}
    api.token = null;
    user = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    notifyListeners();
  }
}
