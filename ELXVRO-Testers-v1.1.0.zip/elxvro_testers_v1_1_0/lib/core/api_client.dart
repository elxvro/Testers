import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'app_config.dart';

class ApiException implements Exception {
  const ApiException(this.message, [this.statusCode]);
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class ApiClient {
  ApiClient({this.token});

  String? token;

  Map<String, String> get _headers => {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
      };

  Uri _uri(String action, [Map<String, String>? query]) {
    final base = Uri.parse(AppConfig.apiBaseUrl);
    return base.replace(queryParameters: {
      ...base.queryParameters,
      'action': action,
      ...?query,
    });
  }

  Future<dynamic> get(String action, [Map<String, String>? query]) async {
    try {
      final response = await http
          .get(_uri(action, query), headers: _headers)
          .timeout(AppConfig.apiTimeout);
      return _decode(response);
    } on TimeoutException {
      throw const ApiException('Sunucu yanıt vermedi. Biraz sonra tekrar deneyin.');
    } on SocketException {
      throw const ApiException('Sunucuya bağlanılamadı. İnternet ve API adresini kontrol edin.');
    } on http.ClientException {
      throw const ApiException('Sunucu bağlantısı kurulamadı.');
    }
  }

  Future<dynamic> post(String action, Map<String, dynamic> body) async {
    try {
      final response = await http
          .post(
            _uri(action),
            headers: _headers,
            body: jsonEncode(body),
          )
          .timeout(AppConfig.apiTimeout);
      return _decode(response);
    } on TimeoutException {
      throw const ApiException('Sunucu yanıt vermedi. Biraz sonra tekrar deneyin.');
    } on SocketException {
      throw const ApiException('Sunucuya bağlanılamadı. İnternet ve API adresini kontrol edin.');
    } on http.ClientException {
      throw const ApiException('Sunucu bağlantısı kurulamadı.');
    }
  }

  Future<dynamic> delete(String action, Map<String, dynamic> body) async {
    try {
      final response = await http
          .delete(
            _uri(action),
            headers: _headers,
            body: jsonEncode(body),
          )
          .timeout(AppConfig.apiTimeout);
      return _decode(response);
    } on TimeoutException {
      throw const ApiException('Sunucu yanıt vermedi. Biraz sonra tekrar deneyin.');
    } on SocketException {
      throw const ApiException('Sunucuya bağlanılamadı. İnternet ve API adresini kontrol edin.');
    } on http.ClientException {
      throw const ApiException('Sunucu bağlantısı kurulamadı.');
    }
  }

  dynamic _decode(http.Response response) {
    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      throw ApiException('Sunucu geçersiz bir yanıt döndürdü.', response.statusCode);
    }

    if (decoded is! Map<String, dynamic>) {
      throw ApiException('Sunucu yanıt biçimi geçersiz.', response.statusCode);
    }

    if (response.statusCode < 200 || response.statusCode >= 300 || decoded['ok'] != true) {
      throw ApiException(
        decoded['error'] is String ? decoded['error'] as String : 'İstek tamamlanamadı.',
        response.statusCode,
      );
    }
    return decoded['data'];
  }
}
