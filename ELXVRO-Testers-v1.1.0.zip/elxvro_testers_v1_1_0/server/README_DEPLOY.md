# ELXVRO Testers v1.1.0 Backend — cPanel Kurulum

Bu sürüm Google ile giriş, otomatik kullanıcı kaydı, açık test listesi, self-enroll, 14 günlük takip ve geri bildirim içerir.

## 1. MySQL

Yeni kurulumda:

1. cPanel > MySQL Databases bölümünden veritabanı ve kullanıcı oluştur.
2. Kullanıcıya veritabanı için gerekli izinleri ver.
3. phpMyAdmin > Import ile `database/schema.sql` dosyasını içeri aktar.

v1.0 veritabanın zaten kuruluysa `schema.sql` dosyasını tekrar içeri aktarma. Bunun yerine bir kez `database/migrate_v1_0_to_v1_1.sql` çalıştır.

## 2. Sunucu dosyaları

`server` klasörünün içeriğini örneğin şu dizine yükle:

`public_html/elxvro-testers/`

API adresi:

`https://alanadiniz.com/elxvro-testers/api/index.php`

## 3. config.php

`config.php` içinde şunları doldur:

- `DB_HOST`
- `DB_NAME`
- `DB_USER`
- `DB_PASS`
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI`
- `ADMIN_EMAILS`

`ADMIN_EMAILS` listesine yalnızca projeleri yönetecek kendi Google hesabını/h hesaplarını yaz. Arkadaşların bu listeye eklenmez; Google ile ilk girişlerinde otomatik `tester` hesabı olurlar.

## 4. Google OAuth kurulumu

Google Cloud Console'da bir OAuth istemcisi oluştur:

1. OAuth consent screen ayarını tamamla.
2. Credentials > Create credentials > OAuth client ID.
3. Application type olarak **Web application** seç.
4. Authorized redirect URI olarak `config.php` içindeki `GOOGLE_REDIRECT_URI` değerini birebir ekle.
5. OAuth consent screen **Testing** durumundaysa giriş yapacak arkadaşlarının Google hesaplarını OAuth test users listesine de ekle; aksi halde Google girişini yalnızca izin verilen hesaplar kullanabilir.

Örnek:

`https://alanadiniz.com/elxvro-testers/api/index.php?action=google_callback`

Oluşan Web Client ID ve Client Secret değerlerini `config.php` içine yaz.

### Neden Android SHA-1 gerekmiyor?

Bu sürüm Google girişini sunucu taraflı web OAuth ile gerçekleştirir. Uygulama Google'ın güvenli giriş sayfasını açar ve sonucu API üzerinden doğrular. Böylece GitHub Actions'taki mevcut APK akışını ve Android imzasını değiştirmek gerekmez.

## 5. API kontrolü

Tarayıcıda şunu aç:

`https://alanadiniz.com/elxvro-testers/api/index.php?action=health`

Başarılı yanıtta şunları görmelisin:

- `ok: true`
- `version: 1.1.0`
- `google_configured: true`

`google_configured: false` ise `config.php` içindeki Google alanlarından biri hâlâ doldurulmamıştır.

## 6. Flutter API adresi

`lib/core/app_config.dart` içinde şu varsayılan adresi kendi domaininle değiştir:

`https://YOUR-DOMAIN.com/elxvro-testers/api/index.php`

Mevcut GitHub Actions akışına dokunma. Bu sürüm workflow değişikliği gerektirmez.

## Kullanıcı akışı

- Kullanıcı `Google ile devam et` düğmesine basar.
- Google giriş sayfası tarayıcıda açılır.
- İlk başarılı girişte kullanıcı MySQL'e otomatik kaydolur.
- `ADMIN_EMAILS` içindeki hesap yönetici olur; diğer hesaplar testçi olur.
- Testçi açık projeleri doğrudan görür.
- `Teste Katıl` ile proje üyeliği otomatik oluşturulur ve Google Play kapalı test bağlantısı açılır.
- Testçi `Katıldım`, `Yükledim`, `Test ediyorum`, `Tamamladım` durumlarını işaretleyebilir.
- Testçi puan ve geri bildirim gönderebilir.

## Güvenlik

- HTTPS kullan.
- `config.php` dosyasını web erişimine kapalı tut.
- Google Client Secret değerini GitHub'a veya Flutter kaynak koduna koyma; yalnızca hosting tarafındaki `config.php` içinde tut.
- `ADMIN_EMAILS` listesine testçileri ekleme.
- Bu uygulamanın durum kayıtları organizasyon amaçlıdır. Google Play kapalı test katılımının resmi kaynağı Play Console'dur.
