<?php
// ELXVRO Testers server configuration.
// Fill these values before uploading to hosting.
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'YOUR_DATABASE',
    'DB_USER' => 'YOUR_DATABASE_USER',
    'DB_PASS' => 'YOUR_DATABASE_PASSWORD',

    // Google Cloud Console > OAuth 2.0 Client IDs > Web application.
    'GOOGLE_CLIENT_ID' => 'YOUR_GOOGLE_WEB_CLIENT_ID.apps.googleusercontent.com',
    'GOOGLE_CLIENT_SECRET' => 'YOUR_GOOGLE_WEB_CLIENT_SECRET',

    // This exact URL must also be added to "Authorized redirect URIs" in Google Cloud.
    'GOOGLE_REDIRECT_URI' => 'https://YOUR-DOMAIN.com/elxvro-testers/api/index.php?action=google_callback',

    // These Google accounts become app administrators automatically.
    // Friends/testers do not go here.
    'ADMIN_EMAILS' => [
        'YOUR_ADMIN_GMAIL@gmail.com',
    ],

    'TOKEN_DAYS' => 90,

    // Kept only for backwards compatibility with v1.0 API. The v1.1 app uses Google only.
    'ALLOW_PASSWORD_AUTH' => false,
    'ADMIN_SETUP_KEY' => 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET',
];
