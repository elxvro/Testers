-- Run this ONLY if you already imported the v1.0 schema.
-- If this is a fresh installation, import schema.sql instead and do not run this file.

ALTER TABLE users MODIFY password_hash VARCHAR(255) NULL;
ALTER TABLE users ADD COLUMN google_sub VARCHAR(191) NULL AFTER password_hash;
ALTER TABLE users ADD COLUMN avatar_url TEXT NULL AFTER google_sub;
ALTER TABLE users ADD COLUMN last_login_at DATETIME NULL AFTER role;
ALTER TABLE users ADD UNIQUE KEY uq_users_google_sub (google_sub);

ALTER TABLE projects ADD COLUMN is_open TINYINT(1) NOT NULL DEFAULT 1 AFTER test_start_date;
ALTER TABLE projects ADD KEY idx_project_open (is_open,id);

CREATE TABLE google_login_sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_hash CHAR(64) NOT NULL,
  state_hash CHAR(64) NOT NULL,
  status ENUM('pending','complete','failed') NOT NULL DEFAULT 'pending',
  user_id BIGINT UNSIGNED NULL,
  error_message VARCHAR(255) NULL,
  expires_at DATETIME NOT NULL,
  completed_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_google_login_session (session_hash),
  UNIQUE KEY uq_google_login_state (state_hash),
  KEY idx_google_login_expiry (expires_at),
  CONSTRAINT fk_google_login_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
