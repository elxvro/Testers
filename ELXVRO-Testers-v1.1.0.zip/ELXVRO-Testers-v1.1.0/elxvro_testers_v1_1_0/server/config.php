<?php
// ELXVRO Testers server configuration.
// Fill these values before uploading to hosting.
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'elxvrhxw_testers',
    'DB_USER' => 'elxvrhxe_testers_user',
    'DB_PASS' => '5433941661.5423',

    // Google Cloud Console > OAuth 2.0 Client IDs > Web application.
    'GOOGLE_CLIENT_ID' => '227765065065-nedk8gir7b9dl0ocosvp2rg1gnn60npu.apps.googleusercontent.com',
    'GOOGLE_CLIENT_SECRET' => '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',

    // This exact URL must also be added to "Authorized redirect URIs" in Google Cloud.
    'GOOGLE_REDIRECT_URI' => 'https://elxvro.com/elxvro-testers/api/index.php?action=google_callback',

    // These Google accounts become app administrators automatically.
    // Friends/testers do not go here.
    'ADMIN_EMAILS' => [
        'elxvro@gmail.com',
    ],

    'TOKEN_DAYS' => 90,

    // Kept only for backwards compatibility with v1.0 API. The v1.1 app uses Google only.
    'ALLOW_PASSWORD_AUTH' => false,
    'ADMIN_SETUP_KEY' => 'HKdjfksjJdk7dsk8djfkJhdjckscjdjdkc9DMC',
];
