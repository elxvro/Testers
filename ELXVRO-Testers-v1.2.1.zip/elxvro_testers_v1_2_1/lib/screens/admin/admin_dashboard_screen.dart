import 'package:flutter/material.dart';

import '../../core/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';
import 'project_detail_screen.dart';
import 'project_setup_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key, required this.session});
  final SessionController session;

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool _loading = true;
  Map<String, dynamic> _dashboard = {};
  List<dynamic> _projects = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        widget.session.api.get('dashboard'),
        widget.session.api.get('projects'),
      ]);
      if (!mounted) return;
      setState(() {
        _dashboard = results[0] as Map<String, dynamic>;
        _projects = (results[1] as Map<String, dynamic>)['projects'] as List<dynamic>? ?? [];
      });
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _createProject() async {
    final created = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => ProjectSetupScreen(session: widget.session)));
    if (created == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [ElxvroLogo(size: 34), SizedBox(width: 10), Text('ELXVRO Testers')]),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))],
      ),
      floatingActionButton: FloatingActionButton.extended(onPressed: _createProject, icon: const Icon(Icons.add_rounded), label: const Text('Yeni test')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 110),
                children: [
                  const Text('Yönetim paneli', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  const Text('Sınırsız testçi ve grup ile kapalı testlerini tek yerden yönet.', style: TextStyle(color: AppTheme.muted)),
                  const SizedBox(height: 20),
                  Row(children: [
                    Expanded(child: _Metric(title: 'Projeler', value: '${_dashboard['projects'] ?? 0}', icon: Icons.apps_rounded)),
                    const SizedBox(width: 12),
                    Expanded(child: _Metric(title: 'Testçiler', value: '${_dashboard['testers'] ?? 0}', icon: Icons.groups_rounded)),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: _Metric(title: 'Aktif test', value: '${_dashboard['active_tests'] ?? 0}', icon: Icons.timer_rounded)),
                    const SizedBox(width: 12),
                    Expanded(child: _Metric(title: 'Geri bildirim', value: '${_dashboard['feedback'] ?? 0}', icon: Icons.forum_rounded)),
                  ]),
                  const SizedBox(height: 26),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Projeler', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                    Text('${_projects.length}', style: const TextStyle(color: AppTheme.muted)),
                  ]),
                  const SizedBox(height: 12),
                  if (_projects.isEmpty)
                    const SectionCard(child: Text('Henüz test projesi yok. Sağ alttaki “Yeni test” ile ilk projeyi oluştur.', style: TextStyle(color: AppTheme.muted)))
                  else
                    ..._projects.map((raw) {
                      final p = raw as Map<String, dynamic>;
                      final joined = p['joined_count'] ?? 0;
                      final total = p['tester_count'] ?? 0;
                      final registered = p['registered_count'] ?? 0;
                      final groupJoined = p['group_joined_count'] ?? 0;
                      final minimum = p['min_testers'] ?? 12;
                      final unlocked = p['download_unlocked'] == true;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(22),
                          onTap: () async {
                            await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProjectDetailScreen(session: widget.session, projectId: (p['id'] as num).toInt())));
                            _load();
                          },
                          child: SectionCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                const ElxvroLogo(size: 42),
                                const SizedBox(width: 12),
                                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(p['name'] as String? ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                                  Text(p['package_name'] as String? ?? '', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                                ])),
                                const Icon(Icons.chevron_right_rounded, color: AppTheme.muted),
                              ]),
                              const SizedBox(height: 16),
                              Wrap(spacing: 8, runSpacing: 8, children: [
                                StatusPill('$groupJoined / $minimum grup üyesi', color: unlocked ? AppTheme.success : AppTheme.primary),
                                StatusPill('$registered uygulama kaydı'),
                                StatusPill(unlocked ? 'İndirme açık' : 'İndirme kilitli', color: unlocked ? AppTheme.success : AppTheme.primary2),
                                StatusPill('$joined / $total Play durumu'),
                                StatusPill('${p['group_count'] ?? 0} grup'),
                              ]),
                              if (p['test_start_date'] != null) ...[
                                const SizedBox(height: 14),
                                LinearProgressIndicator(value: ((p['elapsed_days'] ?? 0) as num).toDouble() / (((p['test_duration_days'] ?? 14) as num).toDouble().clamp(1, 9999)), minHeight: 8, borderRadius: BorderRadius.circular(99)),
                                const SizedBox(height: 7),
                                Text('Gün ${p['elapsed_days'] ?? 0} / ${p['test_duration_days'] ?? 14}', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                              ],
                            ]),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: AppTheme.primary),
        const SizedBox(height: 16),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 26)),
        Text(title, style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
      ]),
    );
  }
}
