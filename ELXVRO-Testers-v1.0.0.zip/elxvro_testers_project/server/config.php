<?php
// ELXVRO Testers server configuration.
// Replace these values before uploading to hosting.
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'YOUR_DATABASE',
    'DB_USER' => 'YOUR_DATABASE_USER',
    'DB_PASS' => 'YOUR_DATABASE_PASSWORD',
    // Change this to a long random value before first admin registration.
    'ADMIN_SETUP_KEY' => 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET',
    'TOKEN_DAYS' => 90,
];
