<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$config = require __DIR__ . '/../config.php';

function respond($data = null, int $status = 200): never {
    http_response_code($status);
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function fail(string $message, int $status = 400): never {
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function body(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}
function db(): PDO {
    global $config;
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host=' . $config['DB_HOST'] . ';dbname=' . $config['DB_NAME'] . ';charset=utf8mb4',
            $config['DB_USER'],
            $config['DB_PASS'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
        );
    } catch (Throwable $e) {
        fail('Veritabanı bağlantısı kurulamadı. config.php ayarlarını kontrol edin.', 500);
    }
    return $pdo;
}
function bearerToken(): ?string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$header && function_exists('getallheaders')) {
        $h = getallheaders();
        $header = $h['Authorization'] ?? $h['authorization'] ?? '';
    }
    return preg_match('/Bearer\s+(.+)/i', $header, $m) ? trim($m[1]) : null;
}
function currentUser(array $roles = []): array {
    $token = bearerToken();
    if (!$token) fail('Oturum gerekli.', 401);
    $hash = hash('sha256', $token);
    $stmt = db()->prepare('SELECT u.id,u.name,u.email,u.role FROM api_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>NOW() LIMIT 1');
    $stmt->execute([$hash]);
    $user = $stmt->fetch();
    if (!$user) fail('Oturum süresi dolmuş veya geçersiz.', 401);
    if ($roles && !in_array($user['role'], $roles, true)) fail('Bu işlem için yetkiniz yok.', 403);
    bindMemberships((int)$user['id'], (string)$user['email']);
    return $user;
}
function bindMemberships(int $userId, string $email): void {
    $stmt = db()->prepare('UPDATE project_members SET user_id=? WHERE user_id IS NULL AND LOWER(email)=LOWER(?)');
    $stmt->execute([$userId, $email]);
}
function createToken(int $userId): string {
    global $config;
    $token = bin2hex(random_bytes(32));
    $days = max(1, (int)($config['TOKEN_DAYS'] ?? 90));
    $stmt = db()->prepare('INSERT INTO api_tokens(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL ? DAY))');
    $stmt->execute([$userId, hash('sha256', $token), $days]);
    return $token;
}
function requireOwner(int $projectId, int $adminId): array {
    $stmt = db()->prepare('SELECT * FROM projects WHERE id=? AND created_by=? LIMIT 1');
    $stmt->execute([$projectId, $adminId]);
    $project = $stmt->fetch();
    if (!$project) fail('Proje bulunamadı.', 404);
    return $project;
}
function cleanEmail(string $email): string {
    $email = strtolower(trim($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Geçerli bir e-posta adresi girin.');
    return $email;
}
function projectStats(int $projectId, array $project): array {
    $stmt = db()->prepare("SELECT COUNT(*) total, SUM(status<>'invited') joined, SUM(status IN ('installed','testing','completed')) installed FROM project_members WHERE project_id=?");
    $stmt->execute([$projectId]);
    $s = $stmt->fetch() ?: ['total'=>0,'joined'=>0,'installed'=>0];
    $elapsed = 0;
    if (!empty($project['test_start_date'])) {
        $elapsed = max(1, (int)((new DateTimeImmutable('today'))->diff(new DateTimeImmutable($project['test_start_date']))->days) + 1);
        if (new DateTimeImmutable($project['test_start_date']) > new DateTimeImmutable('today')) $elapsed = 0;
    }
    $duration = max(1, (int)$project['test_duration_days']);
    return [
        'total' => (int)$s['total'], 'joined' => (int)$s['joined'], 'installed' => (int)$s['installed'],
        'elapsed_days' => min($elapsed, $duration), 'remaining_days' => max(0, $duration - $elapsed),
    ];
}

$action = $_GET['action'] ?? 'health';
$method = $_SERVER['REQUEST_METHOD'];
$input = body();

try {
    if ($action === 'health') {
        respond(['service'=>'ELXVRO Testers API','php'=>PHP_VERSION,'time'=>date(DATE_ATOM)]);
    }

    if ($action === 'register' && $method === 'POST') {
        $name = trim((string)($input['name'] ?? ''));
        $email = cleanEmail((string)($input['email'] ?? ''));
        $password = (string)($input['password'] ?? '');
        if ($name === '' || mb_strlen($name) > 120) fail('Ad alanını kontrol edin.');
        if (strlen($password) < 8) fail('Şifre en az 8 karakter olmalı.');
        $pdo = db();
        $check = $pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1');
        $check->execute([$email]);
        if ($check->fetch()) fail('Bu e-posta zaten kayıtlı.', 409);
        $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
        $role = 'tester';
        if ($adminCount === 0 && isset($input['setup_key']) && hash_equals((string)$config['ADMIN_SETUP_KEY'], (string)$input['setup_key'])) {
            $role = 'admin';
        }
        $stmt = $pdo->prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)');
        $stmt->execute([$name,$email,password_hash($password, PASSWORD_DEFAULT),$role]);
        $id = (int)$pdo->lastInsertId();
        bindMemberships($id, $email);
        $token = createToken($id);
        respond(['token'=>$token,'user'=>['id'=>$id,'name'=>$name,'email'=>$email,'role'=>$role]], 201);
    }

    if ($action === 'login' && $method === 'POST') {
        $email = cleanEmail((string)($input['email'] ?? ''));
        $stmt = db()->prepare('SELECT id,name,email,password_hash,role FROM users WHERE email=? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify((string)($input['password'] ?? ''), $user['password_hash'])) fail('E-posta veya şifre hatalı.', 401);
        bindMemberships((int)$user['id'], $user['email']);
        $token = createToken((int)$user['id']);
        unset($user['password_hash']);
        $user['id'] = (int)$user['id'];
        respond(['token'=>$token,'user'=>$user]);
    }

    if ($action === 'logout' && $method === 'POST') {
        currentUser();
        $token = bearerToken();
        if ($token) { $stmt = db()->prepare('DELETE FROM api_tokens WHERE token_hash=?'); $stmt->execute([hash('sha256',$token)]); }
        respond(['logged_out'=>true]);
    }

    if ($action === 'me') {
        $u = currentUser();
        $u['id'] = (int)$u['id'];
        respond(['user'=>$u]);
    }

    if ($action === 'dashboard') {
        $u = currentUser(['admin']);
        $pdo = db();
        $q = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE created_by=?'); $q->execute([$u['id']]); $projects=(int)$q->fetchColumn();
        $q = $pdo->prepare('SELECT COUNT(*) FROM project_members pm JOIN projects p ON p.id=pm.project_id WHERE p.created_by=?'); $q->execute([$u['id']]); $testers=(int)$q->fetchColumn();
        $q = $pdo->prepare('SELECT COUNT(*) FROM projects WHERE created_by=? AND test_start_date IS NOT NULL'); $q->execute([$u['id']]); $active=(int)$q->fetchColumn();
        $q = $pdo->prepare('SELECT COUNT(*) FROM feedback f JOIN projects p ON p.id=f.project_id WHERE p.created_by=?'); $q->execute([$u['id']]); $feedback=(int)$q->fetchColumn();
        respond(['projects'=>$projects,'testers'=>$testers,'active_tests'=>$active,'feedback'=>$feedback]);
    }

    if ($action === 'projects') {
        $u = currentUser();
        $pdo = db();
        if ($u['role'] === 'admin') {
            $stmt = $pdo->prepare("SELECT p.*, (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id=p.id) tester_count, (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id=p.id AND pm.status<>'invited') joined_count, (SELECT COUNT(*) FROM tester_groups g WHERE g.project_id=p.id) group_count FROM projects p WHERE p.created_by=? ORDER BY p.id DESC");
            $stmt->execute([$u['id']]);
        } else {
            $stmt = $pdo->prepare("SELECT p.*, 1 tester_count, IF(pm.status<>'invited',1,0) joined_count, (SELECT COUNT(*) FROM tester_groups g WHERE g.project_id=p.id) group_count FROM projects p JOIN project_members pm ON pm.project_id=p.id WHERE pm.user_id=? ORDER BY p.id DESC");
            $stmt->execute([$u['id']]);
        }
        $items = $stmt->fetchAll();
        foreach ($items as &$p) {
            $stats = projectStats((int)$p['id'], $p);
            $p['id']=(int)$p['id']; $p['tester_count']=(int)$p['tester_count']; $p['joined_count']=(int)$p['joined_count']; $p['group_count']=(int)$p['group_count'];
            $p['elapsed_days']=$stats['elapsed_days']; $p['remaining_days']=$stats['remaining_days']; $p['test_duration_days']=(int)$p['test_duration_days'];
        }
        respond(['projects'=>$items]);
    }

    if ($action === 'project_create' && $method === 'POST') {
        $u = currentUser(['admin']);
        $name = trim((string)($input['name'] ?? ''));
        $package = trim((string)($input['package_name'] ?? ''));
        $url = trim((string)($input['opt_in_url'] ?? ''));
        $groupName = trim((string)($input['group_name'] ?? 'Testçiler'));
        $groupEmail = cleanEmail((string)($input['google_group_email'] ?? ''));
        if ($name === '' || $package === '' || !filter_var($url, FILTER_VALIDATE_URL)) fail('Proje bilgilerini kontrol edin.');
        $min = max(1, (int)($input['min_testers'] ?? 12));
        $days = max(1, (int)($input['test_duration_days'] ?? 14));
        $emails = is_array($input['tester_emails'] ?? null) ? $input['tester_emails'] : [];
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO projects(created_by,name,package_name,opt_in_url,min_testers,test_duration_days) VALUES(?,?,?,?,?,?)');
            $stmt->execute([$u['id'],$name,$package,$url,$min,$days]);
            $projectId=(int)$pdo->lastInsertId();
            $stmt=$pdo->prepare('INSERT INTO tester_groups(project_id,name,google_group_email) VALUES(?,?,?)');
            $stmt->execute([$projectId,$groupName ?: 'Testçiler',$groupEmail]);
            $groupId=(int)$pdo->lastInsertId();
            foreach (array_unique(array_map('strtolower', $emails)) as $rawEmail) {
                if (!filter_var($rawEmail, FILTER_VALIDATE_EMAIL)) continue;
                $uid=null; $q=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $q->execute([$rawEmail]); $found=$q->fetchColumn(); if ($found) $uid=(int)$found;
                $q=$pdo->prepare('INSERT IGNORE INTO project_members(project_id,user_id,email,status) VALUES(?,?,?,\'invited\')'); $q->execute([$projectId,$uid,$rawEmail]);
                $memberId=(int)$pdo->lastInsertId();
                if ($memberId===0) { $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND email=?'); $q->execute([$projectId,$rawEmail]); $memberId=(int)$q->fetchColumn(); }
                $q=$pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)'); $q->execute([$groupId,$memberId]);
            }
            $pdo->commit();
            respond(['project_id'=>$projectId], 201);
        } catch (Throwable $e) { $pdo->rollBack(); throw $e; }
    }

    if ($action === 'project_detail') {
        $u = currentUser(['admin']);
        $id=(int)($_GET['id'] ?? 0);
        $project=requireOwner($id,(int)$u['id']);
        $pdo=db();
        $q=$pdo->prepare("SELECT g.*, (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id) member_count FROM tester_groups g WHERE g.project_id=? ORDER BY g.id"); $q->execute([$id]); $groups=$q->fetchAll();
        foreach($groups as &$g){$g['id']=(int)$g['id'];$g['member_count']=(int)$g['member_count'];}
        $q=$pdo->prepare('SELECT id,email,name,status,invited_at,joined_at,installed_at,completed_at,user_id FROM project_members WHERE project_id=? ORDER BY id DESC'); $q->execute([$id]); $members=$q->fetchAll();
        foreach($members as &$m){$m['id']=(int)$m['id'];if($m['user_id']!==null)$m['user_id']=(int)$m['user_id'];}
        $q=$pdo->prepare('SELECT f.id,f.rating,f.message,f.created_at,u.name user_name,u.email user_email FROM feedback f JOIN users u ON u.id=f.user_id WHERE f.project_id=? ORDER BY f.id DESC LIMIT 100'); $q->execute([$id]); $feedback=$q->fetchAll();
        foreach($feedback as &$f){$f['id']=(int)$f['id'];$f['rating']=(int)$f['rating'];}
        $project['id']=(int)$project['id']; $project['min_testers']=(int)$project['min_testers']; $project['test_duration_days']=(int)$project['test_duration_days'];
        respond(['project'=>$project,'groups'=>$groups,'members'=>$members,'feedback'=>$feedback,'stats'=>projectStats($id,$project)]);
    }

    if ($action === 'group_create' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $name=trim((string)($input['name']??'')); $email=cleanEmail((string)($input['google_group_email']??'')); if($name==='') fail('Grup adı gerekli.');
        $q=db()->prepare('INSERT INTO tester_groups(project_id,name,google_group_email) VALUES(?,?,?)'); $q->execute([$projectId,$name,$email]); respond(['group_id'=>(int)db()->lastInsertId()],201);
    }

    if ($action === 'project_members') {
        $u=currentUser(['admin']);
        $projectId=(int)($_GET['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $page=max(1,(int)($_GET['page']??1));
        $pageSize=max(20,min(100,(int)($_GET['page_size']??50)));
        $search=trim((string)($_GET['q']??''));
        $offset=($page-1)*$pageSize;
        $pdo=db();
        $where='project_id=?'; $params=[$projectId];
        if($search!=='') { $where.=' AND (email LIKE ? OR name LIKE ?)'; $like='%'.$search.'%'; $params[]=$like; $params[]=$like; }
        $q=$pdo->prepare("SELECT COUNT(*) FROM project_members WHERE $where"); $q->execute($params); $total=(int)$q->fetchColumn();
        $sql="SELECT id,email,name,status,invited_at,joined_at,installed_at,completed_at,user_id FROM project_members WHERE $where ORDER BY id DESC LIMIT $pageSize OFFSET $offset";
        $q=$pdo->prepare($sql); $q->execute($params); $members=$q->fetchAll();
        foreach($members as &$m){$m['id']=(int)$m['id'];if($m['user_id']!==null)$m['user_id']=(int)$m['user_id'];}
        respond(['members'=>$members,'total'=>$total,'page'=>$page,'page_size'=>$pageSize,'has_more'=>($offset+count($members))<$total]);
    }

    if ($action === 'tester_add' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $email=cleanEmail((string)($input['email']??'')); $name=trim((string)($input['name']??'')); $pdo=db();
        $q=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $q->execute([$email]); $uid=$q->fetchColumn();
        $q=$pdo->prepare("INSERT INTO project_members(project_id,user_id,email,name,status) VALUES(?,?,?,?, 'invited') ON DUPLICATE KEY UPDATE user_id=COALESCE(VALUES(user_id),user_id), name=IF(VALUES(name)='',name,VALUES(name))");
        $q->execute([$projectId,$uid?:null,$email,$name?:null]);
        $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND email=?'); $q->execute([$projectId,$email]); $memberId=(int)$q->fetchColumn();
        if(isset($input['group_id'])) { $groupId=(int)$input['group_id']; $g=$pdo->prepare('SELECT id FROM tester_groups WHERE id=? AND project_id=?'); $g->execute([$groupId,$projectId]); if(!$g->fetch()) fail('Grup bulunamadı.',404); $g=$pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)'); $g->execute([$groupId,$memberId]); }
        respond(['member_id'=>$memberId],201);
    }

    if ($action === 'tester_bulk_add' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $emails=is_array($input['emails']??null)?$input['emails']:[]; if(!$emails) fail('E-posta listesi boş.');
        $groupId=isset($input['group_id'])?(int)$input['group_id']:null; $pdo=db();
        if($groupId!==null){$g=$pdo->prepare('SELECT id FROM tester_groups WHERE id=? AND project_id=?');$g->execute([$groupId,$projectId]);if(!$g->fetch())fail('Grup bulunamadı.',404);}
        $added=0; $pdo->beginTransaction();
        try {
            foreach(array_unique(array_map(fn($e)=>strtolower(trim((string)$e)),$emails)) as $email){
                if(!filter_var($email,FILTER_VALIDATE_EMAIL)) continue;
                $q=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1');$q->execute([$email]);$uid=$q->fetchColumn();
                $q=$pdo->prepare("INSERT INTO project_members(project_id,user_id,email,status) VALUES(?,?,?, 'invited') ON DUPLICATE KEY UPDATE user_id=COALESCE(VALUES(user_id),user_id)");
                $q->execute([$projectId,$uid?:null,$email]);
                $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND email=?');$q->execute([$projectId,$email]);$memberId=(int)$q->fetchColumn();
                if($groupId!==null){$g=$pdo->prepare('INSERT IGNORE INTO group_members(group_id,project_member_id) VALUES(?,?)');$g->execute([$groupId,$memberId]);}
                $added++;
            }
            $pdo->commit();
            respond(['processed'=>$added],201);
        } catch(Throwable $e){$pdo->rollBack();throw $e;}
    }

    if ($action === 'project_start' && $method === 'POST') {
        $u=currentUser(['admin']); $projectId=(int)($input['project_id']??0); requireOwner($projectId,(int)$u['id']);
        $q=db()->prepare('UPDATE projects SET test_start_date=COALESCE(test_start_date,CURDATE()) WHERE id=?'); $q->execute([$projectId]); respond(['started'=>true]);
    }

    if ($action === 'tester_tasks') {
        $u=currentUser(['tester','admin']);
        $q=db()->prepare('SELECT p.id project_id,p.name,p.package_name,p.opt_in_url,p.test_start_date,p.test_duration_days,pm.status FROM project_members pm JOIN projects p ON p.id=pm.project_id WHERE pm.user_id=? ORDER BY p.id DESC');
        $q->execute([$u['id']]); $rows=$q->fetchAll(); foreach($rows as &$r){$r['project_id']=(int)$r['project_id'];$r['test_duration_days']=(int)$r['test_duration_days'];}
        respond(['tasks'=>$rows]);
    }

    if ($action === 'tester_status' && $method === 'POST') {
        $u=currentUser(['tester','admin']); $projectId=(int)($input['project_id']??0); $status=(string)($input['status']??'');
        $allowed=['joined','installed','testing','completed']; if(!in_array($status,$allowed,true)) fail('Geçersiz durum.');
        $pdo=db(); $q=$pdo->prepare('SELECT id FROM project_members WHERE project_id=? AND user_id=? LIMIT 1'); $q->execute([$projectId,$u['id']]); $memberId=$q->fetchColumn(); if(!$memberId) fail('Bu projeye atanmış değilsiniz.',403);
        $timeColumn=['joined'=>'joined_at','installed'=>'installed_at','completed'=>'completed_at'][$status] ?? null;
        if($timeColumn){$q=$pdo->prepare("UPDATE project_members SET status=?, $timeColumn=COALESCE($timeColumn,NOW()) WHERE id=?");}else{$q=$pdo->prepare('UPDATE project_members SET status=? WHERE id=?');}
        $q->execute([$status,$memberId]);
        $q=$pdo->prepare('INSERT INTO test_events(project_id,project_member_id,event_type) VALUES(?,?,?)'); $q->execute([$projectId,$memberId,$status]);
        respond(['status'=>$status]);
    }

    if ($action === 'feedback_create' && $method === 'POST') {
        $u=currentUser(['tester','admin']); $projectId=(int)($input['project_id']??0); $rating=max(1,min(5,(int)($input['rating']??5))); $message=trim((string)($input['message']??'')); if($message==='') fail('Geri bildirim boş olamaz.');
        $q=db()->prepare('SELECT id FROM project_members WHERE project_id=? AND user_id=? LIMIT 1'); $q->execute([$projectId,$u['id']]); if(!$q->fetch()) fail('Bu projeye atanmış değilsiniz.',403);
        $q=db()->prepare('INSERT INTO feedback(project_id,user_id,rating,message) VALUES(?,?,?,?)'); $q->execute([$projectId,$u['id'],$rating,$message]); respond(['feedback_id'=>(int)db()->lastInsertId()],201);
    }

    fail('İşlem bulunamadı.', 404);
} catch (PDOException $e) {
    if ((int)$e->getCode() === 23000) fail('Bu kayıt zaten mevcut.', 409);
    fail('Veritabanı işlemi tamamlanamadı.', 500);
} catch (Throwable $e) {
    fail('Sunucu hatası: ' . $e->getMessage(), 500);
}
