# ELXVRO Testers Backend - cPanel Kurulum

1. cPanel'de bir MySQL veritabanı ve kullanıcı oluşturun; kullanıcıya veritabanı üzerinde tüm gerekli izinleri verin.
2. `database/schema.sql` dosyasını phpMyAdmin > Import üzerinden içeri aktarın.
3. `server` klasörünün içeriğini örneğin `public_html/elxvro-testers/` altına yükleyin.
4. `config.php` içindeki DB bilgilerini doldurun ve `ADMIN_SETUP_KEY` değerini uzun/rastgele bir değerle değiştirin.
5. API adresi şu biçimde olacaktır: `https://alanadiniz.com/elxvro-testers/api/index.php`.
6. Tarayıcıdan `...?action=health` açıldığında JSON `ok:true` dönmelidir.
7. Flutter tarafında `lib/core/app_config.dart` içindeki varsayılan API adresini değiştirin veya build sırasında `--dart-define=API_BASE_URL=https://.../api/index.php` kullanın.
8. Uygulamada ilk hesabı oluştururken “İlk yönetici hesabını kuruyorum” seçeneğini açıp `ADMIN_SETUP_KEY` değerini girin. İlk admin oluşturulduktan sonra normal kayıtlar testçi olur.

## Güvenlik

- Yalnızca HTTPS kullanın.
- `ADMIN_SETUP_KEY` değerini kimseyle paylaşmayın ve ilk kurulumdan sonra isterseniz yeniden değiştirin.
- Veritabanı şifresini GitHub'a yüklemeyin.
- `config.php` `.htaccess` ile web erişimine kapatılmıştır; yine de dosya izinlerini hosting politikanıza göre sıkı tutun.

## Not

Bu servis Play Console'un resmi tester doğrulama API'si değildir. `joined`, `installed` vb. durumlar testçinin uygulama içindeki beyanı ve ekip içi takiptir. Google Play/Play Console kaydı resmi kaynaktır.
