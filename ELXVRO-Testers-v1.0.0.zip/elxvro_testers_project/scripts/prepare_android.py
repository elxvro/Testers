from pathlib import Path
import shutil

p = Path('android/app/build.gradle.kts')
if not p.exists():
    raise SystemExit('android/app/build.gradle.kts bulunamadı. Önce Android platformunu üretin.')
text = p.read_text(encoding='utf-8')

if 'import java.util.Properties' not in text:
    text = 'import java.util.Properties\nimport java.io.FileInputStream\n\n' + text

anchor = 'android {'
props = """val keystoreProperties = Properties()\nval keystorePropertiesFile = rootProject.file(\"key.properties\")\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(FileInputStream(keystorePropertiesFile))\n}\n\n"""
if 'val keystoreProperties = Properties()' not in text:
    text = text.replace(anchor, props + anchor, 1)

old_pkg = 'com.elxvro.elxvro_testers'
new_pkg = 'com.elxvro.testers'
text = text.replace(f'namespace = "{old_pkg}"', f'namespace = "{new_pkg}"')
text = text.replace(f'applicationId = "{old_pkg}"', f'applicationId = "{new_pkg}"')

if 'create("release")' not in text:
    marker = '    buildTypes {'
    signing = """    signingConfigs {\n        if (keystorePropertiesFile.exists()) {\n            create(\"release\") {\n                keyAlias = keystoreProperties[\"keyAlias\"] as String\n                keyPassword = keystoreProperties[\"keyPassword\"] as String\n                storeFile = file(keystoreProperties[\"storeFile\"] as String)\n                storePassword = keystoreProperties[\"storePassword\"] as String\n            }\n        }\n    }\n\n"""
    text = text.replace(marker, signing + marker, 1)

text = text.replace(
    'signingConfig = signingConfigs.getByName("debug")',
    'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")',
)
p.write_text(text, encoding='utf-8')

manifest = Path('android/app/src/main/AndroidManifest.xml')
if manifest.exists():
    m = manifest.read_text(encoding='utf-8')
    m = m.replace('android:label="elxvro_testers"', 'android:label="ELXVRO Testers"')
    manifest.write_text(m, encoding='utf-8')

old_main = Path('android/app/src/main/kotlin/com/elxvro/elxvro_testers/MainActivity.kt')
new_main = Path('android/app/src/main/kotlin/com/elxvro/testers/MainActivity.kt')
if old_main.exists():
    new_main.parent.mkdir(parents=True, exist_ok=True)
    main_text = old_main.read_text(encoding='utf-8').replace(f'package {old_pkg}', f'package {new_pkg}')
    new_main.write_text(main_text, encoding='utf-8')
    old_main.unlink()
    # Remove empty old package directories when possible.
    for candidate in [old_main.parent, old_main.parent.parent]:
        try:
            candidate.rmdir()
        except OSError:
            pass

print('Android release signing, uygulama adı ve paket ayarları hazırlandı.')
