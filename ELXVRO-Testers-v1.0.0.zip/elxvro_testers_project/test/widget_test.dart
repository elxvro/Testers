import 'package:flutter_test/flutter_test.dart';

void main() {
  test('basic sanity', () {
    expect(12 + 2, 14);
  });
}
