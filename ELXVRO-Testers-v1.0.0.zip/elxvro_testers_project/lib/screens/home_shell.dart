import 'package:flutter/material.dart';

import '../core/session_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';
import 'admin/admin_dashboard_screen.dart';
import 'tester/tester_dashboard_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.session});
  final SessionController session;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final user = widget.session.user!;
    final pages = <Widget>[
      user.isAdmin ? AdminDashboardScreen(session: widget.session) : TesterDashboardScreen(session: widget.session),
      _Profile(session: widget.session),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        backgroundColor: AppTheme.panel,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'Panel'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profil'),
        ],
      ),
    );
  }
}

class _Profile extends StatelessWidget {
  const _Profile({required this.session});
  final SessionController session;

  @override
  Widget build(BuildContext context) {
    final user = session.user!;
    return Scaffold(
      appBar: AppBar(title: const Row(children: [ElxvroLogo(size: 34), SizedBox(width: 10), Text('Profil')]), actions: [IconButton(onPressed: session.logout, icon: const Icon(Icons.logout_rounded), tooltip: 'Çıkış yap')]),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          SectionCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(user.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(user.email, style: const TextStyle(color: AppTheme.muted)),
              const SizedBox(height: 14),
              StatusPill(user.isAdmin ? 'Yönetici' : 'Testçi'),
            ]),
          ),
          const SizedBox(height: 16),
          const SectionCard(child: Text('ELXVRO Testers, testçi gruplarını, davetleri, 14 günlük süreci ve geri bildirimleri düzenlemek için tasarlanmıştır. Uygulama içi durumlar kullanıcı beyanı ve yönetici takibidir; resmi kapalı test durumu Play Console tarafından belirlenir.', style: TextStyle(color: AppTheme.muted, height: 1.5))),
        ],
      ),
    );
  }
}
