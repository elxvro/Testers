import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';

class ProjectDetailScreen extends StatefulWidget {
  const ProjectDetailScreen({super.key, required this.session, required this.projectId});
  final SessionController session;
  final int projectId;

  @override
  State<ProjectDetailScreen> createState() => _ProjectDetailScreenState();
}

class _ProjectDetailScreenState extends State<ProjectDetailScreen> {
  bool _loading = true;
  bool _loadingMembers = false;
  Map<String, dynamic>? _data;
  final List<dynamic> _members = [];
  final _memberSearch = TextEditingController();
  int _memberPage = 1;
  int _membersTotal = 0;
  bool _hasMoreMembers = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _memberSearch.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await widget.session.api.get('project_detail', {'id': '${widget.projectId}'}) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => _data = data);
      await _loadMembers(reset: true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMembers({bool reset = false}) async {
    if (_loadingMembers) return;
    if (reset) _memberPage = 1;
    setState(() => _loadingMembers = true);
    try {
      final data = await widget.session.api.get('project_members', {
        'project_id': '${widget.projectId}',
        'page': '$_memberPage',
        'page_size': '50',
        if (_memberSearch.text.trim().isNotEmpty) 'q': _memberSearch.text.trim(),
      }) as Map<String, dynamic>;
      if (!mounted) return;
      final incoming = data['members'] as List<dynamic>? ?? [];
      setState(() {
        if (reset) _members.clear();
        _members.addAll(incoming);
        _membersTotal = (data['total'] as num?)?.toInt() ?? _members.length;
        _hasMoreMembers = data['has_more'] == true;
      });
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _loadingMembers = false);
    }
  }

  Future<void> _start() async {
    try {
      await widget.session.api.post('project_start', {'project_id': widget.projectId});
      _load();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _addTester() async {
    final email = TextEditingController();
    final name = TextEditingController();
    final groups = (_data?['groups'] as List<dynamic>? ?? []);
    int? groupId = groups.isEmpty ? null : (groups.first['id'] as num).toInt();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Testçi ekle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-posta')),
              const SizedBox(height: 12),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Ad (isteğe bağlı)')),
              if (groups.isNotEmpty) ...[
                const SizedBox(height: 12),
                DropdownButtonFormField<int?>(
                  initialValue: groupId,
                  decoration: const InputDecoration(labelText: 'Grup'),
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('Grupsuz')),
                    ...groups.map((g) => DropdownMenuItem<int?>(value: (g['id'] as num).toInt(), child: Text(g['name'] as String? ?? 'Grup'))),
                  ],
                  onChanged: (v) => setLocal(() => groupId = v),
                ),
              ],
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Ekle')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      await widget.session.api.post('tester_add', {
        'project_id': widget.projectId,
        'email': email.text.trim(),
        'name': name.text.trim(),
        if (groupId != null) 'group_id': groupId,
      });
      await _load();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _bulkAddTesters() async {
    final emails = TextEditingController();
    final groups = (_data?['groups'] as List<dynamic>? ?? []);
    int? groupId = groups.isEmpty ? null : (groups.first['id'] as num).toInt();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Toplu testçi ekle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                controller: emails,
                minLines: 7,
                maxLines: 12,
                decoration: const InputDecoration(labelText: 'E-postalar', hintText: 'ali@gmail.com\nayse@gmail.com\n...'),
              ),
              if (groups.isNotEmpty) ...[
                const SizedBox(height: 12),
                DropdownButtonFormField<int?>(
                  initialValue: groupId,
                  decoration: const InputDecoration(labelText: 'Grup'),
                  items: [
                    const DropdownMenuItem<int?>(value: null, child: Text('Grupsuz')),
                    ...groups.map((g) => DropdownMenuItem<int?>(value: (g['id'] as num).toInt(), child: Text(g['name'] as String? ?? 'Grup'))),
                  ],
                  onChanged: (v) => setLocal(() => groupId = v),
                ),
              ],
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Ekle')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final list = emails.text.split(RegExp(r'[\n,; ]+')).map((e) => e.trim().toLowerCase()).where((e) => e.contains('@')).toSet().toList();
    if (list.isEmpty) {
      if (mounted) showError(context, 'Geçerli e-posta bulunamadı.');
      return;
    }
    try {
      await widget.session.api.post('tester_bulk_add', {
        'project_id': widget.projectId,
        'emails': list,
        if (groupId != null) 'group_id': groupId,
      });
      await _load();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _addGroup() async {
    final name = TextEditingController();
    final email = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yeni grup'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Grup adı')),
          const SizedBox(height: 12),
          TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Google Group e-postası')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Oluştur')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.session.api.post('group_create', {
        'project_id': widget.projectId,
        'name': name.text.trim(),
        'google_group_email': email.text.trim(),
      });
      _load();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _data == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final d = _data ?? {};
    final p = d['project'] as Map<String, dynamic>? ?? {};
    final stats = d['stats'] as Map<String, dynamic>? ?? {};
    final groups = d['groups'] as List<dynamic>? ?? [];
    final feedback = d['feedback'] as List<dynamic>? ?? [];
    final url = p['opt_in_url'] as String? ?? '';
    final elapsed = (stats['elapsed_days'] as num?)?.toInt() ?? 0;
    final duration = (p['test_duration_days'] as num?)?.toInt() ?? 14;

    return Scaffold(
      appBar: AppBar(
        title: Text(p['name'] as String? ?? 'Proje'),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 40),
          children: [
            SectionCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const ElxvroLogo(size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(p['name'] as String? ?? '', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      Text(p['package_name'] as String? ?? '', style: const TextStyle(color: AppTheme.muted)),
                    ]),
                  ),
                ]),
                const SizedBox(height: 20),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  StatusPill('${stats['joined'] ?? 0}/${stats['total'] ?? 0} katıldı', color: AppTheme.success),
                  StatusPill('${groups.length} grup'),
                  StatusPill('${feedback.length} geri bildirim', color: AppTheme.primary2),
                ]),
                const SizedBox(height: 18),
                if (p['test_start_date'] == null)
                  FilledButton.icon(onPressed: _start, icon: const Icon(Icons.play_arrow_rounded), label: const Text('14 günlük takibi başlat'))
                else ...[
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('Gün $elapsed / $duration', style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text('${stats['remaining_days'] ?? 0} gün kaldı', style: const TextStyle(color: AppTheme.muted)),
                  ]),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(value: (elapsed / duration).clamp(0, 1).toDouble(), minHeight: 10, borderRadius: BorderRadius.circular(99)),
                ],
              ]),
            ),
            const SizedBox(height: 14),
            SectionCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Katılım bağlantısı', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                const SizedBox(height: 10),
                SelectableText(url, style: const TextStyle(color: AppTheme.muted)),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: url));
                        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bağlantı kopyalandı.')));
                      },
                      icon: const Icon(Icons.copy_rounded),
                      label: const Text('Kopyala'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: OutlinedButton.icon(onPressed: () => Share.share('Kapalı teste katıl: $url'), icon: const Icon(Icons.share_rounded), label: const Text('Paylaş'))),
                ]),
              ]),
            ),
            const SizedBox(height: 22),
            Row(children: [
              const Expanded(child: Text('Gruplar', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
              IconButton(onPressed: _addGroup, icon: const Icon(Icons.add_circle_outline_rounded)),
            ]),
            const SizedBox(height: 8),
            if (groups.isEmpty)
              const SectionCard(child: Text('Grup yok.', style: TextStyle(color: AppTheme.muted)))
            else
              ...groups.map((raw) {
                final g = raw as Map<String, dynamic>;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SectionCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      const Icon(Icons.groups_rounded, color: AppTheme.primary),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(g['name'] as String? ?? 'Grup', style: const TextStyle(fontWeight: FontWeight.w800)),
                          Text(g['google_group_email'] as String? ?? '', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                        ]),
                      ),
                      StatusPill('${g['member_count'] ?? 0} kişi'),
                    ]),
                  ),
                );
              }),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: Text('Testçiler ($_membersTotal)', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
              IconButton(onPressed: _bulkAddTesters, icon: const Icon(Icons.group_add_rounded), tooltip: 'Toplu ekle'),
              IconButton(onPressed: _addTester, icon: const Icon(Icons.person_add_alt_1_rounded), tooltip: 'Tek testçi ekle'),
            ]),
            const SizedBox(height: 8),
            TextField(
              controller: _memberSearch,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Ad veya e-posta ara',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _memberSearch.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _memberSearch.clear();
                          _loadMembers(reset: true);
                        },
                        icon: const Icon(Icons.close_rounded),
                      ),
              ),
              onChanged: (_) => setState(() {}),
              onSubmitted: (_) => _loadMembers(reset: true),
            ),
            const SizedBox(height: 10),
            if (_members.isEmpty && !_loadingMembers)
              const SectionCard(child: Text('Eşleşen testçi bulunamadı.', style: TextStyle(color: AppTheme.muted)))
            else
              ..._members.map((raw) {
                final m = raw as Map<String, dynamic>;
                final status = m['status'] as String? ?? 'invited';
                final color = status == 'joined' || status == 'installed' || status == 'testing' || status == 'completed' ? AppTheme.success : AppTheme.primary;
                final name = (m['name'] as String?)?.trim() ?? '';
                final email = m['email'] as String? ?? '';
                final initial = (name.isNotEmpty ? name : email).isNotEmpty ? (name.isNotEmpty ? name : email)[0].toUpperCase() : '?';
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: SectionCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      CircleAvatar(backgroundColor: AppTheme.panel2, child: Text(initial)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(name.isNotEmpty ? name : email, style: const TextStyle(fontWeight: FontWeight.w700)),
                          if (name.isNotEmpty) Text(email, style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
                        ]),
                      ),
                      StatusPill(_statusText(status), color: color),
                    ]),
                  ),
                );
              }),
            if (_loadingMembers)
              const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
            else if (_hasMoreMembers)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: OutlinedButton(
                  onPressed: () {
                    _memberPage++;
                    _loadMembers();
                  },
                  child: const Text('Daha fazla yükle'),
                ),
              ),
            if (feedback.isNotEmpty) ...[
              const SizedBox(height: 22),
              const Text('Geri bildirimler', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              ...feedback.map((raw) {
                final f = raw as Map<String, dynamic>;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: SectionCard(
                    padding: const EdgeInsets.all(14),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(f['user_name'] as String? ?? f['user_email'] as String? ?? 'Testçi', style: const TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 5),
                      Text(f['message'] as String? ?? '', style: const TextStyle(color: AppTheme.muted, height: 1.4)),
                      const SizedBox(height: 8),
                      Text('Puan: ${f['rating'] ?? '-'} / 5', style: const TextStyle(color: AppTheme.primary, fontSize: 12)),
                    ]),
                  ),
                );
              }),
            ],
          ],
        ),
      ),
    );
  }

  String _statusText(String status) {
    const map = {
      'invited': 'Davet edildi',
      'joined': 'Katıldı',
      'installed': 'Yüklendi',
      'testing': 'Test ediyor',
      'completed': 'Tamamladı',
    };
    return map[status] ?? status;
  }
}
