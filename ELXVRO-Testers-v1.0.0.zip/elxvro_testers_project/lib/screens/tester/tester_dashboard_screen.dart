import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';

class TesterDashboardScreen extends StatefulWidget {
  const TesterDashboardScreen({super.key, required this.session});
  final SessionController session;

  @override
  State<TesterDashboardScreen> createState() => _TesterDashboardScreenState();
}

class _TesterDashboardScreenState extends State<TesterDashboardScreen> {
  bool _loading = true;
  List<dynamic> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await widget.session.api.get('tester_tasks') as Map<String, dynamic>;
      if (mounted) setState(() => _tasks = data['tasks'] as List<dynamic>? ?? []);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _mark(int projectId, String status) async {
    try {
      await widget.session.api.post('tester_status', {'project_id': projectId, 'status': status});
      _load();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _join(Map<String, dynamic> task) async {
    final url = Uri.tryParse(task['opt_in_url'] as String? ?? '');
    if (url == null || !await launchUrl(url, mode: LaunchMode.externalApplication)) {
      if (mounted) showError(context, 'Google Play test bağlantısı açılamadı.');
      return;
    }
  }

  Future<void> _feedback(int projectId) async {
    final message = TextEditingController();
    int rating = 5;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
        title: const Text('Geri bildirim gönder'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<int>(initialValue: rating, decoration: const InputDecoration(labelText: 'Puan'), items: [1,2,3,4,5].map((n) => DropdownMenuItem(value: n, child: Text('$n / 5'))).toList(), onChanged: (v) => setLocal(() => rating = v ?? 5)),
          const SizedBox(height: 12),
          TextField(controller: message, minLines: 4, maxLines: 7, decoration: const InputDecoration(labelText: 'Yorum / hata / öneri')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('İptal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Gönder'))],
      )),
    );
    if (ok != true || message.text.trim().isEmpty) return;
    try {
      await widget.session.api.post('feedback_create', {'project_id': projectId, 'rating': rating, 'message': message.text.trim()});
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Geri bildirim gönderildi.')));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Row(children: [ElxvroLogo(size: 34), SizedBox(width: 10), Text('Test Görevlerim')]), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 40),
                children: [
                  Text('Merhaba, ${widget.session.user!.name}', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  const Text('Sana atanan kapalı testleri burada görebilirsin.', style: TextStyle(color: AppTheme.muted)),
                  const SizedBox(height: 22),
                  if (_tasks.isEmpty)
                    const SectionCard(child: Text('Şu anda sana atanmış bir test görevi yok. Yönetici e-posta adresini bir projeye eklediğinde burada görünecek.', style: TextStyle(color: AppTheme.muted, height: 1.5)))
                  else
                    ..._tasks.map((raw) {
                      final t = raw as Map<String, dynamic>;
                      final status = t['status'] as String? ?? 'invited';
                      final id = (t['project_id'] as num).toInt();
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: SectionCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            const ElxvroLogo(size: 46), const SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t['name'] as String? ?? '', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), Text(t['package_name'] as String? ?? '', style: const TextStyle(color: AppTheme.muted, fontSize: 12))])),
                            StatusPill(_statusText(status), color: status == 'invited' ? AppTheme.primary : AppTheme.success),
                          ]),
                          const SizedBox(height: 18),
                          FilledButton.icon(onPressed: () => _join(t), icon: const Icon(Icons.open_in_new_rounded), label: const Text('Google Play’de teste katıl')),
                          const SizedBox(height: 10),
                          Row(children: [
                            Expanded(child: OutlinedButton(onPressed: () => _mark(id, 'joined'), child: const Text('Katıldım'))),
                            const SizedBox(width: 10),
                            Expanded(child: OutlinedButton(onPressed: () => _mark(id, 'installed'), child: const Text('Yükledim'))),
                          ]),
                          const SizedBox(height: 10),
                          OutlinedButton.icon(onPressed: () => _feedback(id), icon: const Icon(Icons.chat_bubble_outline_rounded), label: const Text('Geri bildirim gönder')),
                        ])),
                      );
                    }),
                  const SizedBox(height: 8),
                  const Text('Google Play tarafındaki gerçek katılım ve test süresi resmi kayıttır. Buradaki durum butonları ekip içi takip içindir.', style: TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.4)),
                ],
              ),
            ),
    );
  }

  String _statusText(String status) {
    const map = {'invited': 'Henüz katılmadın', 'joined': 'Katıldın', 'installed': 'Yüklendi', 'testing': 'Test ediliyor', 'completed': 'Tamamlandı'};
    return map[status] ?? status;
  }
}
