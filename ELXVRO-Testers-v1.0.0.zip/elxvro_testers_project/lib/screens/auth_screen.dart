import 'package:flutter/material.dart';

import '../core/session_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/common.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.session});
  final SessionController session;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _setupKey = TextEditingController();
  bool _register = false;
  bool _adminSetup = false;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _setupKey.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_email.text.trim().isEmpty || _password.text.length < 8 || (_register && _name.text.trim().isEmpty)) {
      showError(context, 'Bilgileri kontrol edin. Şifre en az 8 karakter olmalı.');
      return;
    }
    setState(() => _busy = true);
    try {
      if (_register) {
        await widget.session.register(
          name: _name.text,
          email: _email.text,
          password: _password.text,
          setupKey: _adminSetup ? _setupKey.text : null,
        );
      } else {
        await widget.session.login(_email.text, _password.text);
      }
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Row(children: [ElxvroLogo(size: 50), SizedBox(width: 14), Text('ELXVRO Testers', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800))]),
                  const SizedBox(height: 38),
                  Text(_register ? 'Hesap oluştur' : 'Tekrar hoş geldin', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(
                    _register ? 'Test görevlerine katılmak veya kendi testlerini yönetmek için hesap oluştur.' : 'Test paneline devam etmek için giriş yap.',
                    style: const TextStyle(color: AppTheme.muted, height: 1.45),
                  ),
                  const SizedBox(height: 28),
                  if (_register) ...[
                    TextField(controller: _name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Ad soyad')),
                    const SizedBox(height: 14),
                  ],
                  TextField(controller: _email, keyboardType: TextInputType.emailAddress, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'E-posta')),
                  const SizedBox(height: 14),
                  TextField(controller: _password, obscureText: true, onSubmitted: (_) => _submit(), decoration: const InputDecoration(labelText: 'Şifre')),
                  if (_register) ...[
                    const SizedBox(height: 12),
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('İlk yönetici hesabını kuruyorum'),
                      subtitle: const Text('Sadece sunucudaki ADMIN_SETUP_KEY ile ilk kez kullanılabilir.'),
                      value: _adminSetup,
                      onChanged: (v) => setState(() => _adminSetup = v),
                    ),
                    if (_adminSetup) ...[
                      const SizedBox(height: 8),
                      TextField(controller: _setupKey, obscureText: true, decoration: const InputDecoration(labelText: 'Yönetici kurulum anahtarı')),
                    ],
                  ],
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy ? const SizedBox.square(dimension: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(_register ? 'Hesap oluştur' : 'Giriş yap'),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: _busy ? null : () => setState(() => _register = !_register),
                    child: Text(_register ? 'Zaten hesabım var' : 'Yeni hesap oluştur'),
                  ),
                  const SizedBox(height: 16),
                  const Text('Not: Google Play kapalı test katılımının resmi kaydı Play Console tarafındadır. Bu uygulama organizasyon ve takip panelidir.', style: TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.4)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
