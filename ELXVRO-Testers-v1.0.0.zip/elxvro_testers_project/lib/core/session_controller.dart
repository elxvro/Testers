import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_user.dart';
import 'api_client.dart';

class SessionController extends ChangeNotifier {
  SessionController() : api = ApiClient();

  final ApiClient api;
  AppUser? user;
  bool restoring = true;

  bool get signedIn => user != null;

  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    api.token = prefs.getString('auth_token');
    if (api.token != null) {
      try {
        final data = await api.get('me') as Map<String, dynamic>;
        user = AppUser.fromJson(data['user'] as Map<String, dynamic>);
      } catch (_) {
        api.token = null;
        await prefs.remove('auth_token');
      }
    }
    restoring = false;
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    final data = await api.post('login', {
      'email': email.trim(),
      'password': password,
    }) as Map<String, dynamic>;
    await _acceptAuth(data);
  }

  Future<void> register({
    required String name,
    required String email,
    required String password,
    String? setupKey,
  }) async {
    final data = await api.post('register', {
      'name': name.trim(),
      'email': email.trim(),
      'password': password,
      if (setupKey != null && setupKey.trim().isNotEmpty) 'setup_key': setupKey.trim(),
    }) as Map<String, dynamic>;
    await _acceptAuth(data);
  }

  Future<void> _acceptAuth(Map<String, dynamic> data) async {
    api.token = data['token'] as String;
    user = AppUser.fromJson(data['user'] as Map<String, dynamic>);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', api.token!);
    notifyListeners();
  }

  Future<void> logout() async {
    try {
      await api.post('logout', {});
    } catch (_) {}
    api.token = null;
    user = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    notifyListeners();
  }
}
