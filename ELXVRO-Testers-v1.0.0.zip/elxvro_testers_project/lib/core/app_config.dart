class AppConfig {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://YOUR-DOMAIN.com/elxvro-testers/api/index.php',
  );

  static const String appName = 'ELXVRO Testers';
}
