import 'package:flutter/material.dart';

import 'core/app_config.dart';
import 'core/session_controller.dart';
import 'screens/auth_screen.dart';
import 'screens/home_shell.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final session = SessionController();
  await session.restore();
  runApp(ElxvroTestersApp(session: session));
}

class ElxvroTestersApp extends StatelessWidget {
  const ElxvroTestersApp({super.key, required this.session});
  final SessionController session;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: AnimatedBuilder(
        animation: session,
        builder: (context, _) {
          if (session.restoring) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          return session.signedIn ? HomeShell(session: session) : AuthScreen(session: session);
        },
      ),
    );
  }
}
