# ELXVRO Testers

ELXVRO Testers; kendi arkadaş/testçi topluluğunuzla Google Play kapalı test süreçlerini organize etmek için hazırlanmış Flutter + PHP + MySQL projesidir.

## Özellikler

- Yönetici ve testçi hesapları
- Birden fazla proje
- Proje başına sınırsız uygulama içi testçi kaydı
- Proje başına sınırsız testçi grubu kaydı
- Google Group e-postası saklama
- Play Console kapalı test katılım bağlantısı saklama ve paylaşma
- 4 adımlı proje kurulum akışı
- Testçinin “Katıldım / Yükledim” durum güncellemesi
- Geri bildirim ve 1-5 puan
- 14 günlük süreç göstergesi
- PHP 8+ / PDO / MySQL backend
- Bearer token ile oturum
- GitHub Actions ile imzalı release AAB + APK derleme desteği

> Önemli: Bu uygulama Play Console'un resmi testçi durumunu otomatik doğrulamaz. Uygulama içi durumlar ekip içi organizasyon içindir. Resmi kapalı test katılımı ve süreleri Google Play / Play Console kayıtlarına göre değerlendirilir.

## Klasörler

- `lib/` Flutter uygulaması
- `server/` cPanel PHP API
- `server/database/schema.sql` MySQL şeması
- `scripts/prepare_android.py` GitHub build sırasında Android release signing yapılandırması

## Hızlı kurulum

1. Backend için `server/README_DEPLOY.md` adımlarını uygulayın.
2. `lib/core/app_config.dart` içindeki API URL'ini kendi alan adınıza göre değiştirin.
3. Bu ZIP içeriğini GitHub reposuna yükleyin.
4. Yanında verilen `elxvro-testers-build.yml` dosyasını repoda `.github/workflows/elxvro-testers-build.yml` yoluna koyun.
5. GitHub repository Secrets bölümüne şunları ekleyin:
   - `ANDROID_KEYSTORE_BASE64`
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`
6. Actions > ELXVRO Testers Build > Run workflow çalıştırın.
7. Artifact olarak imzalı `.aab` ve `.apk` oluşur.

## Paket adı

GitHub build betiği Android paket adını `com.elxvro.testers` olarak ayarlar.

## Sınırlar

Uygulama kodunda 12 kişilik bir üst sınır yoktur. `12`, yalnızca varsayılan minimum hedef göstergesidir. MySQL tabloları testçi/grup sayısını uygulama düzeyinde sınırlamaz; pratik kapasite hosting kaynaklarına bağlıdır.
